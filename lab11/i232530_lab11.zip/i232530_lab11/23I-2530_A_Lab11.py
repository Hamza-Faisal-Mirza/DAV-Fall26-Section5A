# %% [markdown]
# # Lab 11 - Text Visualization: US Airline Tweets (Feb 2015)
# Roll No: 23I-2530   Section: A
#
# One script: runs every analysis (Parts A-F), saves charts to ./charts and numbers to
# results.json, then builds report.html and brief.html from those numbers.
# Run:  python 23I-2530_A_Lab11.py   (put Tweets.csv beside it or set TWEETS_CSV; needs pandas, matplotlib, seaborn, scikit-learn,
# scipy, nltk, simplemma, wordcloud, vaderSentiment, textblob, matplotlib-venn)

# %% Setup
import re, json, os, warnings
from collections import Counter
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS, TfidfVectorizer
from sklearn.metrics import confusion_matrix, classification_report, f1_score, accuracy_score
from nltk.stem import PorterStemmer
import simplemma
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
from wordcloud import WordCloud
from matplotlib_venn import venn2
warnings.filterwarnings("ignore")

CSV = os.environ.get("TWEETS_CSV", "Tweets.csv")
OUT = "charts"; os.makedirs(OUT, exist_ok=True)
R = {}                                   # all results for the report

NEG, NEU, POS = "#d1522a", "#8a8f98", "#2b7bba"     # sentiment colours (entity-fixed)
SENT_COL = {"negative": NEG, "neutral": NEU, "positive": POS}
INK, GRID = "#2b2f36", "#e3e5e8"
plt.rcParams.update({"figure.dpi": 130, "savefig.dpi": 160, "font.size": 10,
    "axes.edgecolor": "#9aa0a8", "axes.labelcolor": INK, "text.color": INK,
    "xtick.color": INK, "ytick.color": INK, "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "axes.axisbelow": True, "axes.titleweight": "bold", "axes.titlesize": 11,
    "axes.titlelocation": "left", "legend.frameon": False})

def save(fig, name):
    fig.tight_layout(); fig.savefig(f"{OUT}/{name}.png", bbox_inches="tight"); plt.close(fig)

df = pd.read_csv(CSV)
# DATA-QUALITY FIX: rows labelled "Delta" are tweets to @JetBlue (checked in Task 5) -> relabel
df["airline_original"] = df.airline
R["jetblue_fix"] = {"delta_rows": int((df.airline == "Delta").sum()),
    "mention_jetblue": int(((df.airline == "Delta") & df.text.str.contains("@jetblue", case=False)).sum()),
    "mention_delta": int(((df.airline == "Delta") & df.text.str.contains("@delta", case=False)).sum())}
df["airline"] = df.airline.replace({"Delta": "JetBlue"})
df["created"] = pd.to_datetime(df.tweet_created.str[:19])      # local time as written
df["date"] = df.created.dt.date.astype(str)
df["hour"] = df.created.dt.hour
R["n"] = len(df)
R["class_counts"] = df.airline_sentiment.value_counts().to_dict()
R["airline_counts"] = df.airline.value_counts().to_dict()
R["date_range"] = [str(df.created.min()), str(df.created.max())]

# =====================================================================
# PART A - CLEANING
# =====================================================================
URL = re.compile(r"https?://\S+|www\.\S+")
HANDLE = re.compile(r"@\w+")
HASH = re.compile(r"#(\w+)")
STRETCH = re.compile(r"(.)\1{2,}")
NONASCII = re.compile(r"[^\x00-\x7f]")

# ---- Task 1: what breaks a naive tokenizer ---------------------------
def naive_tokens(t):                    # the "textbook" tokenizer: \w+
    return re.findall(r"\w+", t.lower())

feat = {
 "handles (@user)":        df.text.str.contains(HANDLE),
 "hashtags (#tag)":        df.text.str.contains(r"#\w+"),
 "links (http...)":        df.text.str.contains(URL),
 "non-ASCII / emoji":      df.text.apply(lambda s: bool(NONASCII.search(s))),
 "stretched (sooo)":       df.text.str.contains(r"([a-zA-Z])\1{2,}"),
 "contractions (n't)":     df.text.str.contains(r"n['’]t\b", case=False),
 "ALL-CAPS word (4+)":     df.text.str.contains(r"\b[A-Z]{4,}\b"),
 "exclamation !":          df.text.str.contains("!"),
}
R["t1_prevalence"] = {k: int(v.sum()) for k, v in feat.items()}
ex = {
 "handle":      df.text[df.text.str.contains(HANDLE)].iloc[1],
 "hashtag":     df.text[df.text.str.contains(r"#\w+")].iloc[0],
 "link":        df.text[df.text.str.contains(URL)].iloc[0],
 "stretched":   df.text[df.text.str.contains(r"([a-zA-Z])\1{3,}")].iloc[0],
 "contraction": df.text[df.text.str.contains(r"can['’]t", case=False)].iloc[0],
}
R["t1_examples"] = [{"kind": k, "text": v, "naive": naive_tokens(v)} for k, v in ex.items()]

fig, ax = plt.subplots(figsize=(7, 3.4))
s = pd.Series(R["t1_prevalence"]).sort_values()
ax.barh(s.index, s.values / len(df) * 100, color="#4a5568", height=.6)
for i, v in enumerate(s.values): ax.text(v/len(df)*100 + .8, i, f"{v:,}", va="center", fontsize=8.5)
ax.set_xlabel("% of tweets containing the feature"); ax.set_title("Task 1 - How many tweets contain tokenizer-breaking features")
ax.grid(axis="y", visible=False); save(fig, "t01_features")

# cleaning functions ---------------------------------------------------
CONTR = [(r"won['’]t", "will not"), (r"can['’]t", "can not"), (r"cannot", "can not"),
         (r"n['’]t\b", " not"), (r"['’]m\b", " am"), (r"['’]re\b", " are"),
         (r"['’]ve\b", " have"), (r"['’]ll\b", " will"), (r"['’]d\b", " would"), (r"['’]s\b", "")]
def strip_noise(t):                      # steps: url, handle, hashtag
    t = URL.sub(" ", t); t = HANDLE.sub(" ", t); t = HASH.sub(r"\1", t); return t
def expand(t):
    t = t.lower()
    for a, b in CONTR: t = re.sub(a, b, t)
    return t
def letters(t): return re.findall(r"[a-z]+", t)

# vocabulary of "normal" (never stretched) words to decide how far to collapse stretches
_base = Counter(w for t in df.text for w in letters(expand(strip_noise(t))) if not STRETCH.search(w))
def unstretch(w):
    if not STRETCH.search(w): return w
    c2 = STRETCH.sub(r"\1\1", w); c1 = STRETCH.sub(r"\1", w)
    return c1 if _base[c1] > _base[c2] else c2
stretch_examples = []
for t in df.text:
    for w in letters(expand(strip_noise(t))):
        if STRETCH.search(w): stretch_examples.append((w, unstretch(w)))
R["t1_stretch"] = Counter(stretch_examples).most_common(12)
R["t1_stretch_n"] = len(stretch_examples)

R["t1_decisions"] = [
 ["Handles (@united)", "Remove from the text", "They identify the airline, which we already have in the airline column. Left in, they become the top 'words' (Task 5)."],
 ["Hashtags (#fail)", "Keep the word, drop the #", "The tag is the author's own summary (#fail, #neveragain) so it carries sentiment; only the symbol is noise."],
 ["Links (http://t.co/...)", "Remove", "Shortened URLs are random strings; they split into 'http', 't', 'co', 'xyz' and pollute counts."],
 ["Emoji / non-ASCII", "Drop from tokens, count separately", "Rare in this 2015 data (see chart) and the lexicon tools used later cannot read them; dropping loses little."],
 ["Stretched words (sooooo)", "Collapse to the form that exists in the vocabulary", "'sooo' -> 'so', 'goood' -> 'good'. The stretch itself is emphasis; kept as a count for Part F."],
 ["Contractions (can't)", "Expand to 'can not'", "\\w+ cuts \"can't\" into 'can' + 't', which destroys the negation. Expanding keeps 'not' as a token."],
]

# ---- Task 2: negation stop words -------------------------------------
NEGATORS = {"not", "no", "nor", "never", "cannot", "nothing", "nobody", "none", "neither", "nowhere", "without"}
sk = set(ENGLISH_STOP_WORDS)
R["t2_std_contains_neg"] = sorted(sk & NEGATORS)
KEEP = NEGATORS | {"very", "too", "again", "still", "always", "ever", "only", "more", "most", "down", "up", "out", "off", "over", "back", "before", "after", "against", "so", "empty", "fire", "bill", "cry", "cant"}
EXTRA = {"amp", "rt", "via", "http", "https", "co", "u", "im", "ur", "e", "g"}
FINAL_STOP = (sk - KEEP) | EXTRA
R["t2_final_removed_from_std"] = sorted(sk & KEEP)
R["t2_final_stop_size"] = len(FINAL_STOP)

def tok_clean(t):          # cleaned, stretched collapsed, contractions expanded, NO stop removal
    return [unstretch(w) for w in letters(expand(strip_noise(t)))]
df["tok0"] = df.text.apply(tok_clean)
def rm_std(toks):   return [w for w in toks if w not in sk]
def rm_final(toks): return [w for w in toks if w not in FINAL_STOP and len(w) > 1]

vad = SentimentIntensityAnalyzer()
def lab_from_comp(c): return "positive" if c >= .05 else ("negative" if c <= -.05 else "neutral")
def vcomp(s): return vad.polarity_scores(s)["compound"]
# effect on meaning: VADER on token streams
df["s_keep"] = df.tok0.apply(lambda tk: vcomp(" ".join(rm_final(tk))))
df["s_std"]  = df.tok0.apply(lambda tk: vcomp(" ".join(rm_std(tk))))
has_neg = df.tok0.apply(lambda tk: bool(NEGATORS & set(tk)))
R["t2_tweets_with_negator"] = int(has_neg.sum())
R["t2_pct_with_negator"] = round(has_neg.mean() * 100, 1)
acc_keep = accuracy_score(df.airline_sentiment, df.s_keep.apply(lab_from_comp))
acc_std = accuracy_score(df.airline_sentiment, df.s_std.apply(lab_from_comp))
R["t2_acc_keep"], R["t2_acc_std"] = round(acc_keep*100, 2), round(acc_std*100, 2)
sub = df[has_neg]
R["t2_acc_keep_negsub"] = round(accuracy_score(sub.airline_sentiment, sub.s_keep.apply(lab_from_comp))*100, 2)
R["t2_acc_std_negsub"]  = round(accuracy_score(sub.airline_sentiment, sub.s_std.apply(lab_from_comp))*100, 2)
flip = (np.sign(sub.s_keep) != np.sign(sub.s_std))
R["t2_sign_flips"] = int(flip.sum())
ex2 = sub[flip & (sub.s_keep < -.3) & (sub.s_std > .3)].head(5)
R["t2_examples"] = [{"text": r.text, "std_tokens": " ".join(rm_std(r.tok0)), "keep_tokens": " ".join(rm_final(r.tok0)),
                     "s_keep": round(r.s_keep, 2), "s_std": round(r.s_std, 2), "label": r.airline_sentiment} for r in ex2.itertuples()]
# most frequent words that disappear
lost_words = Counter(w for tk in df.tok0 for w in tk if w in NEGATORS)
R["t2_negator_counts"] = lost_words.most_common()

fig, ax = plt.subplots(1, 2, figsize=(8, 3.3))
ax[0].bar(["Standard list\n(negators removed)", "Final list\n(negators kept)"], [acc_std*100, acc_keep*100], color=["#8a8f98", "#2b7bba"], width=.55)
ax[0].set_ylim(0, 100); ax[0].set_title("All tweets"); ax[0].set_ylabel("VADER agreement with human label (%)")
for i, v in enumerate([acc_std*100, acc_keep*100]): ax[0].text(i, v+1.5, f"{v:.1f}%", ha="center")
a, b = R["t2_acc_std_negsub"], R["t2_acc_keep_negsub"]
ax[1].bar(["Standard list", "Final list"], [a, b], color=["#8a8f98", "#2b7bba"], width=.55)
ax[1].set_ylim(0, 100); ax[1].set_title(f"Only tweets containing a negator (n={len(sub):,})")
for i, v in enumerate([a, b]): ax[1].text(i, v+1.5, f"{v:.1f}%", ha="center")
for x in ax: x.grid(axis="x", visible=False)
fig.suptitle("Task 2 - Removing 'not/no/nor' changes what the sentiment tool sees", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t02_negation")

# ---- Task 3: stemming vs lemmatization -------------------------------
ps = PorterStemmer()
base_tokens = [w for tk in df.tok0 for w in rm_final(tk)]
vocab = Counter(base_tokens)
stem_of = {w: ps.stem(w) for w in vocab}
LEM_FIX = {"cancelled": "cancel", "canceled": "cancel", "cancelling": "cancel", "cancels": "cancel", "canceling": "cancel", "cancellation": "cancel", "cancellations": "cancel", "cancell": "cancel", "united": "united"}
lem_raw = {w: simplemma.lemmatize(w, lang="en") for w in vocab}      # plain lemmatizer, for the Task 3 comparison
lem_of = {w: LEM_FIX.get(w, lem_raw[w]) for w in vocab}               # final choice = lemmatizer + 4 domain fixes
R["t3_vocab"] = {"after_stop_removal": len(vocab), "stemmed": len(set(stem_of.values())), "lemmatized": len(set(lem_of.values()))}
dis = [(w, c, stem_of[w], lem_raw[w]) for w, c in vocab.most_common() if stem_of[w] != lem_raw[w]]
R["t3_disagree_n"] = len(dis)
R["t3_disagree_top"] = dis[:25]
# stems that merge unrelated words
groups = {}
for w in vocab: groups.setdefault(stem_of[w], []).append(w)
over = [(s, sorted(ws, key=lambda x: -vocab[x])[:5]) for s, ws in groups.items()
        if len({lem_raw[w] for w in ws}) >= 2 and sum(vocab[w] for w in ws) >= 30]
over.sort(key=lambda x: -sum(vocab[w] for w in groups[x[0]]))
R["t3_overstem"] = over[:12]
nonword = [(w, stem_of[w], vocab[w]) for w in vocab if stem_of[w] not in vocab and stem_of[w] != lem_of[w] and vocab[w] >= 100]
R["t3_nonword_stems"] = sorted(nonword, key=lambda x: -x[2])[:12]
lem_bad = [(w, lem_of[w], vocab[w]) for w in vocab if lem_of[w] != w and vocab[w] >= 60 and lem_of[w] not in vocab][:12]
R["t3_lemma_changes"] = sorted([(w, lem_raw[w], vocab[w]) for w in vocab if lem_raw[w] != w and vocab[w] >= 80], key=lambda x: -x[2])[:20]
R["t3_vocab"]["lemmatized_plain"] = len(set(lem_raw.values()))
fig, ax = plt.subplots(figsize=(6.4, 3))
v = R["t3_vocab"]; names = ["Cleaned\n(no stemming)", "Porter stem", "Lemmatized"]
vals = [v["after_stop_removal"], v["stemmed"], v["lemmatized"]]
ax.bar(names, vals, color=["#8a8f98", "#d1a02a", "#2b7bba"], width=.55)
for i, x in enumerate(vals): ax.text(i, x+120, f"{x:,}  ({(1-x/vals[0])*100:.0f}% smaller)" if i else f"{x:,}", ha="center", fontsize=9)
ax.set_ylim(0, max(vals)*1.15); ax.set_ylabel("Distinct tokens"); ax.grid(axis="x", visible=False)
ax.set_title("Task 3 - Vocabulary size before and after"); save(fig, "t03_vocab")

# ---- Task 4: cost of every cleaning step -----------------------------
def lem_list(tk): return [lem_of.get(w) or simplemma.lemmatize(w, lang="en") for w in tk]
steps = []
def rec(name, toklists):
    lens = np.array([len(t) for t in toklists])
    steps.append({"step": name, "vocab": len(set(w for t in toklists for w in t)), "mean_len": round(lens.mean(), 2), "empty": int((lens == 0).sum())})
s0 = [t.split() for t in df.text]; rec("0 Raw (split on spaces)", s0)
s1 = [t.lower().split() for t in df.text]; rec("1 Lowercase", s1)
s2 = [URL.sub(" ", t.lower()).split() for t in df.text]; rec("2 + remove links", s2)
s3 = [HANDLE.sub(" ", URL.sub(" ", t.lower())).split() for t in df.text]; rec("3 + remove @handles", s3)
s4 = [letters(strip_noise(t.lower())) for t in df.text]; rec("4 + hashtags->words, strip punctuation/digits/emoji", s4)
s5 = [[unstretch(w) for w in letters(expand(strip_noise(t)))] for t in df.text]; rec("5 + expand contractions, collapse stretches", s5)
s6 = [rm_final(t) for t in s5]; rec("6 + stop words (final list, negators kept)", s6)
s6b = [[w for w in t if w not in sk and len(w) > 1] for t in s5]; rec("6b (alt) standard stop list instead", s6b)
s7 = [lem_list(t) for t in s6]; rec("7 + lemmatize (final pipeline)", s7)
df["tokens"] = s7
R["t4_steps"] = steps
step_df = pd.DataFrame(steps)
main = step_df[~step_df.step.str.startswith("6b")]
fig, ax = plt.subplots(1, 3, figsize=(11, 3.8), sharey=True)
lab = [s.split(" ")[0] for s in main.step]
for a_, col, ttl, c in zip(ax, ["vocab", "mean_len", "empty"], ["Distinct tokens", "Mean tokens per tweet", "Tweets left empty"], ["#4a5568", "#2b7bba", "#d1522a"]):
    a_.barh(lab[::-1], main[col].values[::-1], color=c, height=.6); a_.set_title(ttl); a_.grid(axis="y", visible=False)
    for i, val in enumerate(main[col].values[::-1]): a_.text(val, i, f" {val:,}", va="center", fontsize=8)
    a_.set_xlim(0, main[col].max()*1.22)
ax[0].set_ylabel("Cleaning step (cumulative)")
fig.suptitle("Task 4 - What each cleaning step costs (steps numbered as in the table)", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t04_cost")

# =====================================================================
# PART B - WORD AND PHRASE FREQUENCY
# =====================================================================
AIRLINE_TERMS = {"united", "usairways", "us", "airways", "american", "americanair", "southwest", "southwestair", "delta", "virgin", "america", "virginamerica",
                 "jetblue", "airline", "airlines", "air", "usair", "aa", "unitedairlines", "virginamerica", "flight", "flights", "flightled", "flighted", "get", "got", "can", "will", "just", "would", "need", "amp", "thank", "thanks"}
# ---- Task 5 ------------------------------------------------------------
raw_top = Counter(w for t in df.text for w in t.lower().split()).most_common(15)
R["t5_raw_top"] = raw_top
step_top = Counter(w for tk in df.tokens for w in tk).most_common(15)
R["t5_clean_top"] = step_top
GENERIC = {"flight", "flightled", "flighted", "get", "got", "go", "going", "would", "can", "will", "just", "need", "amp", "airline", "airlines", "thank", "thanks", "us", "like", "know", "one", "time", "call", "want", "make", "day", "http"}
AIR_TOK = {"united", "usairways", "americanair", "southwestair", "jetblue", "virginamerica", "delta", "american", "southwest", "virgin", "america", "usair", "us", "airways", "aa", "unitedairlines", "airline", "airlines"}
FILLER = {"do", "did", "does", "so", "up", "out", "still", "very", "too", "more", "most", "only", "ever", "always", "again", "back", "over", "off", "down", "after", "before", "against", "go", "get", "got", "say", "make", "know", "see", "take", "come", "look", "tell", "try", "give", "flightled", "flightr", "flightl", "flighted", "reflight", "empty", "fire", "bill", "cry", "cant", "hr", "min", "minute", "hour", "amp"}
DROP5 = AIR_TOK | GENERIC | (FILLER - {"hour", "minute", "min", "hr"})
df["tok_b"] = df.tokens.apply(lambda tk: [w for w in tk if w not in DROP5])
fix_top = Counter(w for tk in df.tok_b for w in tk).most_common(15)
R["t5_fixed_top"] = fix_top
# how was it collected?
own = {"United": "@united", "US Airways": "@usairways", "American": "@americanair", "Southwest": "@southwestair", "JetBlue": "@jetblue", "Virgin America": "@virginamerica"}
R["t5_handle_share"] = round(np.mean([own[a].lower() in t.lower() for a, t in zip(df.airline, df.text)]) * 100, 1)
R["t5_starts_with_handle"] = round(df.text.str.startswith("@").mean() * 100, 1)
R["t5_has_any_handle"] = round(df.text.str.contains("@").mean() * 100, 1)
R["t5_competitor_mention"] = int(sum((any(h.lower() in t.lower() for k, h in own.items() if k != a)) for a, t in zip(df.airline, df.text)))
fig, ax = plt.subplots(1, 2, figsize=(10, 4.3))
for a_, data, ttl, c in [(ax[0], raw_top, "Raw: split on spaces", "#8a8f98"), (ax[1], fix_top, "Fixed: handles, airline names and filler removed", "#2b7bba")]:
    w, cnt = zip(*data[::-1]); a_.barh(w, cnt, color=c, height=.65); a_.set_title(ttl); a_.grid(axis="y", visible=False)
    for i, x in enumerate(cnt): a_.text(x, i, f" {x:,}", va="center", fontsize=8)
    a_.set_xlim(0, max(cnt)*1.15)
fig.suptitle("Task 5 - Top 15 words before and after fixing the airline-name problem", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t05_dominance")

# ---- Task 6 ------------------------------------------------------------
cls = ["negative", "neutral", "positive"]
cnt = {c: Counter(w for tk in df[df.airline_sentiment == c].tok_b for w in tk) for c in cls}
top20 = {c: [w for w, _ in cnt[c].most_common(20)] for c in cls}
R["t6_top20"] = top20
R["t6_overlap_pos_neg"] = sorted(set(top20["positive"]) & set(top20["negative"]))
docs = [" ".join(w for tk in df[df.airline_sentiment == c].tok_b for w in tk) for c in cls]
tf = TfidfVectorizer(sublinear_tf=True, token_pattern=r"\S+", min_df=1)
M = tf.fit_transform(docs); terms = np.array(tf.get_feature_names_out())
tfidf_top = {}
for i, c in enumerate(cls):
    row = M[i].toarray()[0]
    ok = np.array([cnt[c][t] >= 15 for t in terms])
    idx = np.argsort(-(row*ok))[:12]; tfidf_top[c] = [(terms[j], round(float(row[j]), 3), cnt[c][terms[j]]) for j in idx]
R["t6_tfidf"] = tfidf_top
fig, ax = plt.subplots(1, 3, figsize=(12, 4))
for a_, c in zip(ax, cls):
    w, s_, _ = zip(*tfidf_top[c][::-1]); a_.barh(w, s_, color=SENT_COL[c], height=.65); a_.set_title(f"{c.title()} tweets"); a_.grid(axis="y", visible=False)
fig.suptitle("Task 6 - Most distinctive words per class (TF-IDF, each class = one document, min 15 uses)", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t06_tfidf")
# butterfly (log-odds, informative prior = whole corpus)
tot = Counter(); [tot.update(c_) for c_ in cnt.values()]
a0 = 0.5; N = sum(tot.values()); nn, npos = sum(cnt["negative"].values()), sum(cnt["positive"].values())
rows = []
for w, c_all in tot.items():
    if cnt["negative"][w] + cnt["positive"][w] < 25: continue
    pri = a0 * 1000 * c_all / N + 0.01
    ln = np.log((cnt["negative"][w] + pri) / (nn + 1000*a0 - cnt["negative"][w] - pri)); lp = np.log((cnt["positive"][w] + pri) / (npos + 1000*a0 - cnt["positive"][w] - pri))
    rows.append((w, ln - lp, cnt["negative"][w], cnt["positive"][w]))
rows.sort(key=lambda x: x[1]); lo = rows[:12]; hi = rows[-12:]
R["t6_logodds_neg"] = [(w, round(z, 2), a, b) for w, z, a, b in hi[::-1]]
R["t6_logodds_pos"] = [(w, round(z, 2), a, b) for w, z, a, b in lo]
fig, ax = plt.subplots(figsize=(8.2, 5.4))
sel = lo + hi; y = np.arange(len(sel))
ax.barh(y, [r[1] for r in sel], color=[POS if r[1] < 0 else NEG for r in sel], height=.7)
ax.set_yticks(y, [r[0] for r in sel]); ax.axvline(0, color=INK, lw=.8); ax.grid(axis="y", visible=False)
ax.set_xlabel("<- more typical of POSITIVE tweets          log-odds ratio          more typical of NEGATIVE tweets ->")
ax.set_title("Task 6 - Butterfly chart: words that separate negative from positive tweets"); save(fig, "t06_butterfly")

# ---- Task 7: n-grams ---------------------------------------------------
negdf = df[df.airline_sentiment == "negative"]
def ngrams(toklists, n):
    c = Counter()
    for tk in toklists:
        c.update(zip(*[tk[i:] for i in range(n)]))
    return c
# adjacency on tokens with filler removed but negators kept
def tokn(tk):
    out = [w for w in tk if w not in {"airline", "airlines", "flightled", "flighted", "flightr", "flightl", "reflight", "amp"} and w not in AIR_TOK]
    return [w for i, w in enumerate(out) if i == 0 or w != out[i-1]]
neg_tok = [tokn(t) for t in negdf.tokens]
bi = ngrams(neg_tok, 2); tri = ngrams(neg_tok, 3)
R["t7_bigrams"] = [(" ".join(k), v) for k, v in bi.most_common(30)]
R["t7_trigrams"] = [(" ".join(k), v) for k, v in tri.most_common(20)]
# flip candidates
pos_tok = [tokn(t) for t in df[df.airline_sentiment == "positive"].tokens]
bi_pos = ngrams(pos_tok, 2); all_tok = [tokn(t) for t in df.tokens]; bi_all = ngrams(all_tok, 2)
lex = vad.lexicon
flip_rows = []
for k, v in bi_all.items():
    if v < 6: continue
    parts = [lex.get(w, 0) for w in k]
    if min(parts) < -0.5 and (bi_pos[k] / v) >= .5:
        flip_rows.append((" ".join(k), v, bi_pos[k], parts))
flip_rows.sort(key=lambda x: -x[1]); R["t7_flip_cands"] = flip_rows[:12]
for cand in [("no", "problem"), ("not", "bad"), ("thank", "god"), ("no", "complaint"), ("no", "issue")]:
    R.setdefault("t7_flip_check", []).append({"bigram": " ".join(cand), "total": bi_all[cand], "in_positive": bi_pos[cand], "in_negative": bi[cand]})
op_cands = [("customer", "service"), ("hold", "hour"), ("lose", "luggage"), ("lost", "luggage"), ("cancel", "flight"), ("wait", "hour"), ("call", "back"), ("hold", "time"),
            ("miss", "connection"), ("late", "flight"), ("flight", "delay"), ("gate", "agent"), ("baggage", "claim"), ("lose", "bag"), ("hour", "late"), ("hour", "delay"), ("hold", "min"), ("hour", "hold"), ("wait", "hour")]
R["t7_op_check"] = [{"bigram": " ".join(c), "neg": bi[c]} for c in op_cands if bi[c] > 0]
top_bi = bi.most_common(15)
fig, ax = plt.subplots(1, 2, figsize=(11, 4.6))
w, c_ = zip(*[(" ".join(k), v) for k, v in top_bi[::-1]]); ax[0].barh(w, c_, color=NEG, height=.65); ax[0].set_title("Top bigrams in negative tweets"); ax[0].grid(axis="y", visible=False)
top_tri = tri.most_common(15); w, c_ = zip(*[(" ".join(k), v) for k, v in top_tri[::-1]]); ax[1].barh(w, c_, color="#b3401d", height=.65); ax[1].set_title("Top trigrams in negative tweets"); ax[1].grid(axis="y", visible=False)
fig.suptitle("Task 7 - Phrases in negative tweets (stop words removed, negators kept)", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t07_ngrams")

# ---- Task 8: cloud vs bar ---------------------------------------------
negcnt = Counter(w for tk in negdf.tok_b for w in tk)
fig, ax = plt.subplots(1, 2, figsize=(12, 4.6), gridspec_kw={"width_ratios": [1.2, 1]})
wc = WordCloud(width=800, height=520, background_color="white", colormap="Oranges", max_words=40, random_state=3, prefer_horizontal=.9).generate_from_frequencies(dict(negcnt.most_common(40)))
ax[0].imshow(wc, interpolation="bilinear"); ax[0].axis("off"); ax[0].set_title("A. Word cloud (top 40 negative words)")
w, c_ = zip(*negcnt.most_common(15)[::-1]); ax[1].barh(w, c_, color=NEG, height=.65); ax[1].set_title("B. Bar chart (top 15, same data)"); ax[1].grid(axis="y", visible=False)
for i, x in enumerate(c_): ax[1].text(x, i, f" {x:,}", va="center", fontsize=8)
ax[1].set_xlim(0, max(c_)*1.15); fig.suptitle("Task 8 - Same negative words, two charts", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t08_cloud_vs_bar")
R["t8_top"] = negcnt.most_common(15)
R["t8_ratio_1_2"] = [negcnt.most_common(3)[i] for i in range(3)]

# =====================================================================
# PART C - SENTIMENT TOOL VS HUMAN LABELS
# =====================================================================
def clean_for_vader(t): return URL.sub(" ", HANDLE.sub(" ", t))
df["vclean"] = df.text.apply(clean_for_vader)
df["vader"] = df.vclean.apply(vcomp); df["vlab"] = df.vader.apply(lab_from_comp)
df["tb"] = df.vclean.apply(lambda s: TextBlob(s).sentiment.polarity)
df["tblab"] = df.tb.apply(lambda c: "positive" if c > .05 else ("negative" if c < -.05 else "neutral"))
y, yp = df.airline_sentiment, df.vlab
R["t9_acc"] = round(accuracy_score(y, yp)*100, 2); R["t9_acc_tb"] = round(accuracy_score(y, df.tblab)*100, 2)
R["t9_macro_f1"] = round(f1_score(y, yp, average="macro")*100, 2)
R["t9_baseline_always_neg"] = round((y == "negative").mean()*100, 2)
rep = classification_report(y, yp, output_dict=True, labels=cls)
R["t9_report"] = {c: {k: round(rep[c][k], 3) for k in ["precision", "recall", "f1-score", "support"]} for c in cls}
cm = confusion_matrix(y, yp, labels=cls); R["t9_cm"] = cm.tolist()
fig, ax = plt.subplots(1, 2, figsize=(10, 3.9))
for a_, mat, fmt, ttl in [(ax[0], cm, "d", "Counts"), (ax[1], cm / cm.sum(1, keepdims=True), ".0%", "Share of each human class (row %)")]:
    sns.heatmap(mat, annot=True, fmt=fmt, cmap="Blues", xticklabels=cls, yticklabels=cls, cbar=False, ax=a_, linewidths=2, linecolor="white")
    a_.set_xlabel("VADER says"); a_.set_ylabel("Humans say"); a_.set_title(ttl); a_.grid(False)
fig.suptitle(f"Task 9 - VADER vs human labels (overall agreement {R['t9_acc']:.1f}%)", x=.01, ha="left", fontweight="bold", fontsize=11)
save(fig, "t09_confusion")
# box plot of compound by human class
fig, ax = plt.subplots(figsize=(6.2, 3.6))
sns.boxplot(data=df, x="airline_sentiment", y="vader", order=cls, palette=SENT_COL, ax=ax, width=.5, fliersize=1.5, linewidth=1)
ax.set_xlabel("Human label"); ax.set_ylabel("VADER compound"); ax.set_title("Task 9 - Spread of VADER scores per human class"); ax.grid(axis="x", visible=False)
save(fig, "t09_box")

# ---- Task 10: disagreements ------------------------------------------
num = {"negative": -1, "neutral": 0, "positive": 1}
df["hnum"] = df.airline_sentiment.map(num)
df["gap"] = (df.vader - df.hnum).abs()
dis = df[df.vlab != df.airline_sentiment].copy()
R["t10_n_disagree"] = len(dis); R["t10_pct_disagree"] = round(len(dis)/len(df)*100, 1)
DOMAIN = r"\b(delay\w*|cancel\w*|lost|lose|losing|stuck|stranded|hold|wait\w*|late|luggage|bags?|baggage|miss(ed)?|overbook\w*|rebook\w*|diverted|hours?|hrs?|refund)\b"
SARC = r"(thanks? (a lot|for nothing|for (the )?(delay|cancel|lost|losing|ruin))|great job|nice job|love (how|that|when|waiting)|yeah right|oh great|real nice|awesome.*(delay|cancel|lost|wait)|way to go|good job|(delay|cancel|wait|lost).*(great|awesome|fantastic|love|brilliant)|\bsure\b.*\byeah\b|#fail)"
MIXED = r"\b(but|however|although|though|yet|except|unfortunately)\b"
def negation_scope(r):               # a negator within 3 tokens BEFORE a polar word
    toks = re.findall(r"[a-z']+", r.text.lower())
    for i, w in enumerate(toks):
        if w in NEGATORS or w.endswith("n't") or w.endswith("n’t"):
            if any(vad.lexicon.get(x, 0) != 0 for x in toks[i+1:i+4]): return True
    return False
def cause(r):
    t = r.text.lower()
    if re.search(SARC, t): return "Sarcasm / irony"
    if r.airline_sentiment == "negative" and re.search(DOMAIN, t) and r.vader > -0.05: return "Airline words not negative in lexicon"
    if negation_scope(r): return "Negation (flips a polar word)"
    if re.search(MIXED, t): return "Mixed feelings"
    if r.airline_sentiment == "neutral": return "Humans neutral, tool sees polarity"
    if r.airline_sentiment == "negative" and abs(r.vader) < .05: return "No lexicon words (neutral-sounding complaint)"
    return "Other"
dis["cause"] = dis.apply(cause, axis=1)
cc = dis.cause.value_counts(); R["t10_causes"] = cc.to_dict()
R["t10_cause_by_dir"] = dis.groupby(["cause", "airline_sentiment"]).size().unstack(fill_value=0).to_dict("index")
top_dis = dis.sort_values("gap", ascending=False).head(8)
R["t10_worst"] = [{"text": r.text, "label": r.airline_sentiment, "vader": round(r.vader, 2), "cause": r.cause} for r in top_dis.itertuples()]
R["t10_examples_by_cause"] = {c: [{"text": r.text, "label": r.airline_sentiment, "vader": round(r.vader, 2)} for r in dis[dis.cause == c].sort_values("gap", ascending=False).head(2).itertuples()] for c in cc.index}
fig, ax = plt.subplots(figsize=(8, 3.6))
cc_ = cc[::-1]; ax.barh(cc_.index, cc_.values, color="#4a5568", height=.6); ax.grid(axis="y", visible=False)
for i, v in enumerate(cc_.values): ax.text(v, i, f" {v:,} ({v/len(dis)*100:.0f}%)", va="center", fontsize=8.5)
ax.set_xlim(0, cc.max()*1.25); ax.set_title(f"Task 10 - Why VADER and humans disagree ({len(dis):,} tweets)"); save(fig, "t10_causes")
# proposed fix: airline-domain lexicon
DOMAIN_LEX = {"delayed": -2.2, "delay": -2.0, "delays": -2.0, "cancelled": -2.4, "canceled": -2.4, "cancelled flightled": -2.4, "cancellation": -2.2, "lost": -2.0, "lose": -1.8, "losing": -1.8, "stuck": -2.0, "stranded": -2.5,
              "hold": -1.2, "waiting": -1.2, "wait": -1.0, "waited": -1.5, "late": -1.8, "overbooked": -2.2, "rebook": -0.8, "missed": -1.6, "luggage": -0.3, "baggage": -0.3, "refund": -0.5, "hours": -0.8, "hrs": -0.8, "diverted": -1.5, "unacceptable": -2.5, "worst": -3.0}
vad2 = SentimentIntensityAnalyzer(); vad2.lexicon.update({k: v for k, v in DOMAIN_LEX.items() if " " not in k})
df["vader2"] = df.vclean.apply(lambda s: vad2.polarity_scores(s)["compound"]); df["vlab2"] = df.vader2.apply(lab_from_comp)
R["t10_acc_fixed"] = round(accuracy_score(y, df.vlab2)*100, 2); R["t10_macro_f1_fixed"] = round(f1_score(y, df.vlab2, average="macro")*100, 2)
rep2 = classification_report(y, df.vlab2, output_dict=True, labels=cls); R["t10_recall_fixed"] = {c: round(rep2[c]["recall"], 3) for c in cls}
neg_dis_before = int(((y == "negative") & (df.vlab != "negative")).sum()); neg_dis_after = int(((y == "negative") & (df.vlab2 != "negative")).sum())
R["t10_neg_missed"] = [neg_dis_before, neg_dis_after]
R["t10_domain_lex"] = DOMAIN_LEX
fig, ax = plt.subplots(figsize=(6.4, 3.3))
vals = [R["t9_acc"], R["t10_acc_fixed"]]; ax.bar(["General VADER", "VADER + airline lexicon"], vals, color=["#8a8f98", "#2b7bba"], width=.5); ax.set_ylim(0, 100); ax.grid(axis="x", visible=False)
for i, v in enumerate(vals): ax.text(i, v+1.5, f"{v:.1f}%", ha="center")
ax.set_ylabel("Agreement with human label (%)"); ax.set_title("Task 10 - Effect of adding airline words to the lexicon"); save(fig, "t10_fix")

# ---- Task 11: own tweets ----------------------------------------------
own_tweets = {
 "Negation":  "@united I can't say I was happy and I wouldn't fly with you again, not even for free",
 "Sarcasm":   "@americanair thanks for losing my bag, great job guys, really love sleeping in the airport",
 "Domain/mixed": "@delta flight cancelled at midnight, stuck here with no rebooking, but the gate agent was lovely",
 "Word-count trap": "@southwestair good good good luck getting a good seat, happy to say the app crashed and nobody helped",
}
R["t11"] = []
for k, t in own_tweets.items():
    sc = vad.polarity_scores(clean_for_vader(t)); sc2 = vad2.polarity_scores(clean_for_vader(t))
    pos_w = [w for w in letters(t.lower()) if vad.lexicon.get(w, 0) > 0]; neg_w = [w for w in letters(t.lower()) if vad.lexicon.get(w, 0) < 0]
    R["t11"].append({"type": k, "text": t, "compound": sc["compound"], "label": lab_from_comp(sc["compound"]), "pos_words": pos_w, "neg_words": neg_w, "compound_fixed": sc2["compound"], "label_fixed": lab_from_comp(sc2["compound"])})

# ---- Task 12: label confidence ----------------------------------------
c = df.airline_sentiment_confidence
R["t12_conf_dist"] = {"==1.0": int((c == 1).sum()), ">=0.8": int((c >= .8).sum()), "<0.7": int((c < .7).sum()), "median": float(c.median())}
bins = pd.cut(c, [0, .6, .7, .9999, 1.0], labels=["<=0.6", "0.6-0.7", "0.7-<1", "1.0"], include_lowest=True)
accb = df.groupby(bins).apply(lambda g: pd.Series({"n": len(g), "acc": (g.vlab == g.airline_sentiment).mean()*100}))
R["t12_acc_by_conf"] = accb.round(1).reset_index().astype(str).values.tolist()
hi = df[c >= .8]; lo_ = df[c < .8]
R["t12_hi"] = {"n": len(hi), "acc": round(accuracy_score(hi.airline_sentiment, hi.vlab)*100, 2), "macro_f1": round(f1_score(hi.airline_sentiment, hi.vlab, average="macro")*100, 2),
               "shares": (hi.airline_sentiment.value_counts(normalize=True)*100).round(1).to_dict()}
R["t12_lo"] = {"n": len(lo_), "acc": round(accuracy_score(lo_.airline_sentiment, lo_.vlab)*100, 2), "shares": (lo_.airline_sentiment.value_counts(normalize=True)*100).round(1).to_dict()}
R["t12_all_shares"] = (df.airline_sentiment.value_counts(normalize=True)*100).round(1).to_dict()
neg_share_air_all = df.groupby("airline").apply(lambda g: (g.airline_sentiment == "negative").mean()*100)
neg_share_air_hi = hi.groupby("airline").apply(lambda g: (g.airline_sentiment == "negative").mean()*100)
R["t12_air_all"] = neg_share_air_all.round(1).to_dict(); R["t12_air_hi"] = neg_share_air_hi.round(1).to_dict()
rank_all = list(neg_share_air_all.sort_values(ascending=False).index); rank_hi = list(neg_share_air_hi.sort_values(ascending=False).index)
R["t12_rank_all"], R["t12_rank_hi"] = rank_all, rank_hi
rep_hi = classification_report(hi.airline_sentiment, hi.vlab, output_dict=True, labels=cls); R["t12_recall_hi"] = {k: round(rep_hi[k]["recall"], 3) for k in cls}
hi_neg = Counter(w for tk in hi[hi.airline_sentiment == "negative"].tok_b for w in tk).most_common(12); R["t12_hi_negwords"] = hi_neg
R["t12_top_words_overlap"] = len(set(w for w, _ in Counter(w for tk in negdf.tok_b for w in tk).most_common(30)) & set(w for w, _ in Counter(w for tk in hi[hi.airline_sentiment == "negative"].tok_b for w in tk).most_common(30)))
fig, ax = plt.subplots(1, 2, figsize=(10.5, 3.7))
ab = accb.reset_index(); ax[0].bar(ab.iloc[:, 0].astype(str), ab.acc, color="#2b7bba", width=.6)
for i, (v, n) in enumerate(zip(ab.acc, ab.n)): ax[0].text(i, v+1, f"{v:.0f}%\nn={int(n):,}", ha="center", fontsize=8)
ax[0].set_ylim(0, 100); ax[0].set_xlabel("Human label confidence"); ax[0].set_ylabel("VADER agreement (%)"); ax[0].set_title("Agreement rises with label confidence"); ax[0].grid(axis="x", visible=False)
shares = pd.DataFrame({"All labels": pd.Series(R["t12_all_shares"]), "Confidence >= 0.8": pd.Series(R["t12_hi"]["shares"])}).loc[cls]
shares.T.plot(kind="barh", stacked=True, color=[SENT_COL[k] for k in cls], ax=ax[1], width=.55, edgecolor="white")
for i, r in enumerate(shares.T.values):
    left = 0
    for v in r: ax[1].text(left+v/2, i, f"{v:.0f}%", ha="center", va="center", color="white", fontsize=9, fontweight="bold"); left += v
ax[1].set_xlabel("% of tweets"); ax[1].set_title("Class mix barely changes"); ax[1].legend(ncol=3, loc="upper center", bbox_to_anchor=(.5, -.28)); ax[1].grid(False)
fig.suptitle("Task 12 - Keeping only high-confidence human labels", x=.01, ha="left", fontweight="bold", fontsize=11); save(fig, "t12_confidence")

# =====================================================================
# PART D - AIRLINES AND TIME
# =====================================================================
neg = df[df.airline_sentiment == "negative"].copy()
SERVICE = ["Customer Service Issue", "Flight Attendant Complaints"]
OPS = ["Late Flight", "Cancelled Flight", "Lost Luggage", "Damaged Luggage", "longlines"]
OTHER = ["Bad Flight", "Flight Booking Problems", "Can't Tell"]
ct = pd.crosstab(neg.negativereason, neg.airline); R["t13_counts"] = ct.to_dict()
ctp = ct / ct.sum() * 100; R["t13_pct"] = ctp.round(1).to_dict()
chi2, p, dof, _ = stats.chi2_contingency(ct); R["t13_chi2"] = {"chi2": round(chi2, 1), "p": float(p), "dof": int(dof), "cramers_v": round(float(np.sqrt(chi2 / (ct.values.sum() * (min(ct.shape) - 1)))), 3)}
named = neg[~neg.negativereason.isin(["Can't Tell"]) & neg.negativereason.notna()]
grp = named.assign(group=np.where(named.negativereason.isin(SERVICE), "Service", np.where(named.negativereason.isin(OPS), "Operations", "Other (bad flight / booking)")))
gct = pd.crosstab(grp.airline, grp.group); gp = gct.div(gct.sum(1), axis=0)*100
R["t13_group_counts"] = gct.to_dict("index"); R["t13_group_pct"] = gp.round(1).to_dict("index")
sv = gct[["Service", "Operations"]]; chi_so = stats.chi2_contingency(sv); R["t13_chi_service_ops"] = {"chi2": round(chi_so[0], 1), "p": float(chi_so[1])}
# share of ALL tweets that are service / ops complaints (so volume counts too)
tot_air = df.airline.value_counts()
R["t13_rate_per_100"] = {a: {"service": round(gct.loc[a, "Service"] / tot_air[a] * 100, 1), "ops": round(gct.loc[a, "Operations"] / tot_air[a] * 100, 1)} for a in gct.index}
order = list(gp.sort_values("Service", ascending=False).index)
fig, ax = plt.subplots(1, 2, figsize=(12, 4.8), gridspec_kw={"width_ratios": [1.25, 1]})
sns.heatmap(ctp.loc[ctp.sum(1).sort_values(ascending=False).index, order], annot=True, fmt=".0f", cmap="Oranges", cbar=False, ax=ax[0], linewidths=2, linecolor="white"); ax[0].set_title("% of each airline's negative tweets, by reason"); ax[0].set_xlabel(""); ax[0].set_ylabel(""); ax[0].grid(False)
gp.loc[order, ["Service", "Operations", "Other (bad flight / booking)"]].plot(kind="barh", stacked=True, color=["#2b7bba", "#d1522a", "#c9ccd1"], ax=ax[1], width=.6, edgecolor="white")
for i, a in enumerate(order):
    left = 0
    for g in ["Service", "Operations", "Other (bad flight / booking)"]:
        v = gp.loc[a, g]; ax[1].text(left+v/2, i, f"{v:.0f}%", ha="center", va="center", color="white" if g != "Other (bad flight / booking)" else INK, fontsize=8.5); left += v
ax[1].set_title("Service vs operations (known reasons only)"); ax[1].legend(ncol=3, loc="lower center", bbox_to_anchor=(.45, -.2), fontsize=8); ax[1].grid(False); ax[1].invert_yaxis(); ax[1].set_ylabel("")
fig.suptitle("Task 13 - Mix of complaints differs by airline", x=.01, ha="left", fontweight="bold", fontsize=11); save(fig, "t13_mix")

# Task 14
g = df.groupby("airline").apply(lambda g: pd.Series({"tweets": len(g), "neg": (g.airline_sentiment == "negative").sum(), "pos": (g.airline_sentiment == "positive").sum()}))
g["neg_share"] = g.neg / g.tweets*100; g["pos_share"] = g.pos / g.tweets*100
z = 1.96; ph = g.neg / g.tweets
g["lo"] = ((ph + z*z/(2*g.tweets) - z*np.sqrt(ph*(1-ph)/g.tweets + z*z/(4*g.tweets**2))) / (1 + z*z/g.tweets))*100
g["hi"] = ((ph + z*z/(2*g.tweets) + z*np.sqrt(ph*(1-ph)/g.tweets + z*z/(4*g.tweets**2))) / (1 + z*z/g.tweets))*100
R["t14"] = g.round(1).to_dict("index")
gs = g.sort_values("neg", ascending=False)
fig, ax = plt.subplots(1, 2, figsize=(11, 3.9), sharey=True)
ax[0].barh(gs.index, gs.neg, color="#8a8f98", height=.6); ax[0].invert_yaxis(); ax[0].set_title("Negative tweets (raw count)"); ax[0].grid(axis="y", visible=False)
for i, v in enumerate(gs.neg): ax[0].text(v, i, f" {int(v):,}", va="center", fontsize=9)
ax[0].set_xlim(0, gs.neg.max()*1.15)
ax[1].barh(gs.index, gs.neg_share, color=NEG, height=.6, xerr=[gs.neg_share-gs.lo, gs.hi-gs.neg_share], error_kw={"ecolor": INK, "lw": 1, "capsize": 3}); ax[1].set_title("Negative share of the airline's tweets (95% CI)"); ax[1].grid(axis="y", visible=False)
for i, v in enumerate(gs.neg_share): ax[1].text(gs.hi.iloc[i]+1, i, f"{v:.0f}%", va="center", fontsize=9)
ax[1].set_xlim(0, 100)
fig.suptitle("Task 14 - Raw count and share rank airlines differently", x=.01, ha="left", fontweight="bold", fontsize=11); save(fig, "t14_count_vs_share")

# Task 15
daily = df.groupby("date").apply(lambda g: pd.Series({"tweets": len(g), "neg": (g.airline_sentiment == "negative").sum()})); daily["share"] = daily.neg / daily.tweets*100
R["t15_daily"] = daily.round(1).reset_index().values.tolist()
hr = df.groupby("hour").apply(lambda g: pd.Series({"tweets": len(g), "share": (g.airline_sentiment == "negative").mean()*100}))
R["t15_hour_corr_note"] = hr.round(1).reset_index().values.tolist()
da = df.groupby(["date", "airline"]).apply(lambda g: (g.airline_sentiment == "negative").mean()*100).unstack()
R["t15_daily_by_airline"] = da.round(0).to_dict("index")
dr = pd.crosstab(neg.date, neg.negativereason, normalize="index")*100
R["t15_reason_by_day"] = dr.round(1).to_dict("index")
wx = df.text.str.contains(r"\b(weather|storm|snow|ice|winter|blizzard|cold|freez\w*)\b", case=False)
wxd = df.groupby("date").apply(lambda g: wx[g.index].mean()*100); R["t15_weather_pct"] = wxd.round(1).to_dict()
chi_day = stats.chi2_contingency(np.array([daily.neg, daily.tweets - daily.neg])); R["t15_chi_day"] = {"chi2": round(chi_day[0], 1), "p": float(chi_day[1])}
R["t15_peak"] = daily.share.idxmax(), round(float(daily.share.max()), 1), daily.share.idxmin(), round(float(daily.share.min()), 1)
vol = pd.crosstab(df.date, df.airline); R["t15_vol_by_airline"] = vol.to_dict("index")
R["t15_american_first_big_day"] = str(vol.index[(vol["American"] >= 30).argmax()])
core = df[df.airline != "American"]
d2 = core.groupby("date").apply(lambda g: pd.Series({"tweets": len(g), "share": (g.airline_sentiment == "negative").mean()*100}))
R["t15_excl_american"] = d2.round(1).reset_index().values.tolist()
big = daily.index[daily.tweets > 300]
R["t15_share_range_all"] = [round(float(daily.loc[big].share.min()), 1), round(float(daily.loc[big].share.max()), 1)]
R["t15_share_range_core"] = [round(float(d2.loc[big].share.min()), 1), round(float(d2.loc[big].share.max()), 1)]
R["t15_core_volume"] = d2.tweets.astype(int).to_dict()
am_share = (df[df.airline == "American"].airline_sentiment == "negative").mean()*100
fig, ax = plt.subplots(1, 3, figsize=(14, 4.1))
x = np.arange(len(vol)); bottom = np.zeros(len(vol))
AIRC = {"American": "#b3401d", "US Airways": "#d98a5f", "United": "#4a5568", "JetBlue": "#2b7bba", "Southwest": "#7fb2d9", "Virgin America": "#c9ccd1"}
for a_ in ["American", "US Airways", "United", "JetBlue", "Southwest", "Virgin America"]:
    ax[0].bar(x, vol[a_].values, bottom=bottom, color=AIRC[a_], width=.7, label=a_, edgecolor="white", linewidth=.8); bottom += vol[a_].values
lbl = [d[5:] for d in vol.index]; ax[0].set_xticks(x, lbl, rotation=45); ax[0].set_title("Daily tweets by airline"); ax[0].legend(fontsize=7.5, ncol=2); ax[0].grid(axis="x", visible=False)
dsel = [i for i, d in enumerate(daily.index) if daily.tweets.iloc[i] > 300]
ax[1].plot([x[i] for i in dsel], [daily.share.iloc[i] for i in dsel], color=NEG, marker="o", lw=2, label="All six airlines")
ax[1].plot([x[i] for i in dsel], [d2.share.iloc[i] for i in dsel], color=INK, marker="o", lw=2, ls="--", label="Excluding American")
for i in dsel:
    ax[1].text(x[i], daily.share.iloc[i]+2.5, f"{daily.share.iloc[i]:.0f}", ha="center", fontsize=8, color=NEG); ax[1].text(x[i], d2.share.iloc[i]-5.5, f"{d2.share.iloc[i]:.0f}", ha="center", fontsize=8)
ax[1].set_xticks(x, lbl, rotation=45); ax[1].set_ylim(30, 90); ax[1].set_title("Negative share per day (%), days with >300 tweets"); ax[1].legend(fontsize=8, loc="lower right")
dm = da.where(vol >= 30)
sns.heatmap(dm.T, annot=True, fmt=".0f", cmap="Oranges", cbar=False, ax=ax[2], linewidths=1.5, linecolor="white", vmin=20, vmax=95); ax[2].set_xticklabels(lbl, rotation=45); ax[2].set_title("Negative share by airline and day (blank = <30 tweets)"); ax[2].set_xlabel(""); ax[2].set_ylabel(""); ax[2].grid(False)
fig.suptitle("Task 15 - Complaints over time (16-24 Feb 2015; 16 Feb has 4 tweets, 24 Feb is partial)", x=.01, ha="left", fontweight="bold", fontsize=11); save(fig, "t15_time")

# ---- Task 16: urgency rule --------------------------------------------
neg["repeat"] = neg.groupby("name").name.transform("count") >= 2
URG = r"\b(stuck|stranded|missed?|miss(ing)? my|rebook\w*|tonight|right now|asap|help|please|hours?|hrs?|overnight|deplan\w*|tarmac|sitting|waiting|no one|nobody|still)\b"
neg["urgent_words"] = neg.text.str.contains(URG, case=False)
neg["time_critical"] = neg.negativereason.isin(["Cancelled Flight", "Late Flight", "Flight Booking Problems", "Lost Luggage"])
neg["reach"] = neg.retweet_count >= 1
neg["conf_ok"] = neg.airline_sentiment_confidence >= .8
neg["score"] = 3*neg.time_critical + 2*neg.urgent_words + 2*neg.reach + 1*neg.repeat + 0
neg["tier"] = np.where(~neg.conf_ok, "Review (low label confidence)", np.where(neg.score >= 6, "P1 - answer within the hour", np.where(neg.score >= 3, "P2 - same day", "P3 - batch / auto-reply")))
R["t16_tiers"] = neg.tier.value_counts().to_dict(); R["t16_n_neg"] = len(neg)
R["t16_reach"] = {"neg_with_rt": int(neg.reach.sum()), "all_rt_share_neg": round(float(neg.retweet_count.sum() / df.retweet_count.sum()*100), 1), "max_rt": int(df.retweet_count.max())}
R["t16_repeat_users"] = int(neg.groupby("name").name.count().ge(2).sum()); R["t16_repeat_tweets"] = int(neg.repeat.sum())
R["t16_by_tier_reason"] = pd.crosstab(neg.tier, neg.negativereason).to_dict("index")
R["t16_examples"] = {t: [x for x in neg[neg.tier == t].sort_values("score", ascending=False).text.head(2)] for t in neg.tier.unique()}
fig, ax = plt.subplots(figsize=(8, 3.4))
tv = neg.tier.value_counts().reindex(["P1 - answer within the hour", "P2 - same day", "P3 - batch / auto-reply", "Review (low label confidence)"])
ax.barh(tv.index[::-1], tv.values[::-1], color=["#c9ccd1", "#e8a07f", "#d97a4f", "#b3401d"], height=.6); ax.grid(axis="y", visible=False)
for i, v in enumerate(tv.values[::-1]): ax.text(v, i, f" {v:,} ({v/len(neg)*100:.0f}%)", va="center", fontsize=9)
ax.set_xlim(0, tv.max()*1.25); ax.set_title("Task 16 - Where the negative tweets fall under the urgency rule"); save(fig, "t16_tiers")

# =====================================================================
# PART E - evidence for bias / drift
# =====================================================================
R["t17"] = {"neg_share": round((df.airline_sentiment == "negative").mean()*100, 1), "has_location": round(df.tweet_location.notna().mean()*100, 1), "has_coord": round(df.tweet_coord.notna().mean()*100, 2),
            "has_tz": round(df.user_timezone.notna().mean()*100, 1), "cant_tell_of_neg": round((neg.negativereason == "Can't Tell").mean()*100, 1),
            "top_tz": df.user_timezone.value_counts(normalize=True).head(5).mul(100).round(1).to_dict(), "unique_users": int(df.name.nunique()),
            "top_user_tweets": df.name.value_counts().head(5).to_dict(), "tweets_by_top1pct": round(df.name.value_counts().head(int(df.name.nunique()*.01)).sum()/len(df)*100, 1),
            "gold_rows": int(df.airline_sentiment_gold.notna().sum()), "neutral_share": round((df.airline_sentiment == "neutral").mean()*100, 1)}
R["t18_emoji_tweets_pct"] = round(df.text.apply(lambda s: bool(NONASCII.search(s))).mean()*100, 2)
R["t18_mention_other_brands"] = {k: int(df.text.str.contains(k, case=False).sum()) for k in ["jetblue", "alaska", "twitter", "covid", "refund", "wifi", "app"]}
R["t18_neg_reason_share"] = (neg.negativereason.value_counts(normalize=True)*100).round(1).to_dict()

# =====================================================================
# PART F - extra insights
# =====================================================================
# F1: waiting time words
dur = df.text.str.contains(r"\b\d+\s*(hours?|hrs?|h|mins?|minutes?)\b|\b(hours?|hrs?)\b", case=False)
R["f1"] = {"neg_with_duration_pct": round(dur[df.airline_sentiment == "negative"].mean()*100, 1), "pos_with_duration_pct": round(dur[df.airline_sentiment == "positive"].mean()*100, 1),
           "by_reason": neg.assign(d=dur[neg.index]).groupby("negativereason").d.mean().mul(100).round(1).sort_values(ascending=False).to_dict(), "n_dur_neg": int(dur[df.airline_sentiment == "negative"].sum())}
hold = df.text.str.contains(r"\b(on hold|hold time|holding|hung up|phone|call(ed|ing)?|hotline|1-800|customer service|ph?one)\b", case=False)
R["f1"]["phone_neg_pct"] = round(hold[df.airline_sentiment == "negative"].mean()*100, 1); R["f1"]["phone_all_pct"] = round(hold.mean()*100, 1)
cs = neg[neg.negativereason == "Customer Service Issue"]
R["f1"]["cs_words"] = Counter(w for tk in cs.tok_b for w in tk).most_common(12)
R["f1"]["cs_phone_pct"] = round(hold[cs.index].mean()*100, 1)
# F2: amplification
rt = df[df.retweet_count > 0]
R["f2"] = {"tweets_with_rt": len(rt), "pct": round(len(rt)/len(df)*100, 2), "neg_pct_of_rt": round((rt.airline_sentiment == "negative").mean()*100, 1), "neg_pct_all": R["t17"]["neg_share"],
           "rt_total": int(df.retweet_count.sum()), "rt_by_airline": df.groupby("airline").retweet_count.sum().to_dict(), "rt_by_sent": df.groupby("airline_sentiment").retweet_count.sum().to_dict(),
           "rate_by_sent": (df.groupby("airline_sentiment").retweet_count.apply(lambda s: (s > 0).mean()*100)).round(2).to_dict(),
           "top": [{"text": r.text, "rt": int(r.retweet_count), "airline": r.airline, "sent": r.airline_sentiment} for r in df.sort_values("retweet_count", ascending=False).head(3).itertuples()]}
# F3: shouting / punctuation as intensity
df["caps_words"] = df.text.apply(lambda s: len(re.findall(r"\b[A-Z]{3,}\b", HANDLE.sub("", s))))
df["excl"] = df.text.str.count("!"); df["qm"] = df.text.str.count(r"\?")
df["has_caps"] = df.caps_words > 0; df["len"] = df.text.str.len()
R["f3"] = {"caps_by_sent": df.groupby("airline_sentiment").has_caps.mean().mul(100).round(1).to_dict(), "excl_by_sent": df.groupby("airline_sentiment").excl.apply(lambda s: (s > 0).mean()*100).round(1).to_dict(),
           "qm_by_sent": df.groupby("airline_sentiment").qm.apply(lambda s: (s > 0).mean()*100).round(1).to_dict(), "len_by_sent": df.groupby("airline_sentiment").len.mean().round(0).to_dict(),
           "words_by_sent": df.groupby("airline_sentiment").tok_b.apply(lambda s: s.apply(len).mean()).round(2).to_dict(),
           "caps_neg_conf": round(df[df.has_caps & (df.airline_sentiment == "negative")].airline_sentiment_confidence.mean(), 3), "caps_total": int(df.has_caps.sum())}
nl = df.groupby(pd.cut(df.len, [0, 70, 100, 120, 141], labels=["<=70", "71-100", "101-120", "121-140"])).apply(lambda g: (g.airline_sentiment == "negative").mean()*100); R["f3"]["neg_by_len"] = nl.round(1).to_dict()
nlc = df.groupby(pd.cut(df.len, [0, 70, 100, 120, 141], labels=["<=70", "71-100", "101-120", "121-140"])).size(); R["f3"]["n_by_len"] = nlc.to_dict()
# F4: what each airline is praised for
posd = df[df.airline_sentiment == "positive"]
pw = {a: Counter(w for tk in posd[posd.airline == a].tok_b for w in tk) for a in df.airline.unique()}
pt = {a: [(w, c) for w, c in pw[a].most_common(60)] for a in pw}
praise = {}
allp = Counter(); [allp.update(v) for v in pw.values()]
for a in pw:
    n_a = sum(pw[a].values()); rows = []
    for w, c in pw[a].items():
        if c < 8: continue
        rows.append((w, c, (c/n_a) / (allp[w]/sum(allp.values()))))
    praise[a] = [(w, c, round(l, 2)) for w, c, l in sorted(rows, key=lambda r: -r[2])[:6]]
R["f4_praise"] = praise
crew = df.text.str.contains(r"\b(crew|pilot|attendant|agent|staff|employee|team|gate|captain|rep)\b", case=False)
R["f4_staff_mention"] = {"pos": round(crew[df.airline_sentiment == "positive"].mean()*100, 1), "neg": round(crew[df.airline_sentiment == "negative"].mean()*100, 1), "neutral": round(crew[df.airline_sentiment == "neutral"].mean()*100, 1)}
R["f4_staff_pos_by_airline"] = posd.assign(c=crew[posd.index]).groupby("airline").c.mean().mul(100).round(1).to_dict()
R["f4_thanks_pos"] = round(posd.text.str.contains(r"\bthank", case=False).mean()*100, 1)
# F5: Time of day pattern
R["f5_hour"] = hr.round(1).reset_index().values.tolist()
R["f5_hours_peak"] = (int(hr.tweets.idxmax()), int(hr.tweets.max()))
# F6: long-run complainers
R["f6"] = {"repeat_neg_users": R["t16_repeat_users"], "repeat_neg_tweets": R["t16_repeat_tweets"], "pct_neg_tweets_from_repeat": round(R["t16_repeat_tweets"]/len(neg)*100, 1)}
R["f6"]["airline_switchers"] = int((df.groupby("name").airline.nunique() > 1).sum())
rep_multi = df.groupby("name").filter(lambda g: len(g) >= 2)
R["f6"]["users_multi"] = int(rep_multi.name.nunique())
R["f6"]["multi_neg_rate"] = round((rep_multi.airline_sentiment == "negative").mean()*100, 1)
R["f6"]["multi_to_airline_same"] = round((rep_multi.groupby("name").airline.nunique() == 1).mean()*100, 1)
# insight chart: complaint intensity cues + audience reach
fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.6))
cs_ = pd.DataFrame({"CAPS word": R["f3"]["caps_by_sent"], "has  !": R["f3"]["excl_by_sent"], "has  ?": R["f3"]["qm_by_sent"]}).loc[cls]
cs_.T.plot(kind="bar", color=[SENT_COL[c] for c in cls], ax=ax[0], width=.75); ax[0].set_ylabel("% of tweets"); ax[0].set_title("Typing cues by human label"); ax[0].tick_params(axis="x", rotation=0); ax[0].legend(fontsize=8); ax[0].grid(axis="x", visible=False)
fd = pd.Series(R["f1"]["by_reason"]).sort_values()
ax[1].barh(fd.index, fd.values, color="#4a5568", height=.6); ax[1].set_title("% of complaints naming a duration/hours, by reason"); ax[1].grid(axis="y", visible=False)
for i, v in enumerate(fd.values): ax[1].text(v, i, f" {v:.0f}%", va="center", fontsize=8)
ax[1].set_xlim(0, max(fd.values)*1.18)
rs = pd.Series(R["f2"]["rate_by_sent"]).loc[cls]; ax[2].bar(cls, rs.values, color=[SENT_COL[c] for c in cls], width=.55); ax[2].set_title("% of tweets that were retweeted at least once"); ax[2].grid(axis="x", visible=False)
for i, v in enumerate(rs.values): ax[2].text(i, v, f"{v:.1f}%", ha="center", va="bottom", fontsize=9)
fig.suptitle("Part F - Extra evidence", x=.01, ha="left", fontweight="bold", fontsize=11); save(fig, "tF_insights")
fig, ax = plt.subplots(figsize=(6.2, 3.4)); nl_ = pd.Series(R["f3"]["neg_by_len"]); ax.bar(nl_.index, nl_.values, color=NEG, width=.6)
for i, (v, n) in enumerate(zip(nl_.values, R["f3"]["n_by_len"].values())): ax.text(i, v+1.5, f"{v:.0f}%\nn={n:,}", ha="center", fontsize=8.5)
ax.set_ylim(0, 100); ax.set_xlabel("Tweet length (characters)"); ax.set_ylabel("% negative"); ax.set_title("Part F - Longer tweets are more often complaints"); ax.grid(axis="x", visible=False); save(fig, "tF_length")
# venn (chart-catalogue item 24): vocab shared between most negative airlines vs most positive airline
ua, uo = R["t13_group_pct"], None
va_words = lambda a: set(w for w, c in Counter(w for tk in neg[neg.airline == a].tok_b for w in tk).items() if c >= 8)
A, B = "US Airways", "Southwest"
fig, ax = plt.subplots(figsize=(5.8, 3.8)); v = venn2([va_words(A), va_words(B)], set_labels=(A, B), set_colors=(NEG, POS), alpha=.55, ax=ax); ax.set_title("Words used >=8 times in negative tweets")
save(fig, "tF_venn")
R["venn"] = {"only_A": sorted(va_words(A) - va_words(B))[:14], "only_B": sorted(va_words(B) - va_words(A))[:14], "A": A, "B": B, "shared_n": len(va_words(A) & va_words(B))}

json.dump(R, open("results.json", "w"), indent=1, default=str)
df.drop(columns=["tok0", "tokens", "tok_b"]).to_csv("scored_tweets.csv", index=False)
print("done", len(os.listdir(OUT)), "charts")


# =====================================================================
# STAGE 2 - build the HTML report and the one-page brief from R (all numbers come from the analysis above)
# =====================================================================
import base64, html as _h
E = _h.escape
def img(name, cap=""):
    cap = cap.replace("&ge;", "≥").replace("&le;", "≤")
    b = base64.b64encode(open(f"{OUT}/{name}.png", "rb").read()).decode()
    return f'<figure><img src="data:image/png;base64,{b}" alt="{E(cap or name)}"><figcaption>{E(cap)}</figcaption></figure>'
def tbl(head, rows, cls=""):
    th = "".join(f"<th>{E(str(x))}</th>" for x in head)
    tr = "".join("<tr>" + "".join(f"<td>{c if isinstance(c, str) else E(str(c))}</td>" for c in r) + "</tr>" for r in rows)
    return f'<table class="{cls}"><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>'
def q(t): return f'<span class="tw">{E(t.replace(chr(10), " ")[:230])}</span>'
def pct(a, b): return f"{a / b * 100:.1f}%"
def box(kind, text): return f'<div class="box {kind}"><b>{kind.title()}:</b> {text}</div>'
R["t9_baseline_always_neg"] = round(R["t9_baseline_always_neg"], 1); R["t10_acc_fixed"] = round(R["t10_acc_fixed"], 1); R["t9_acc"] = round(R["t9_acc"], 1); R["t9_acc_tb"] = round(R["t9_acc_tb"], 1); R["t9_macro_f1"] = round(R["t9_macro_f1"], 1)
N = R["n"]; cc_ = R["class_counts"]; air = R["airline_counts"]
t9 = R["t9_report"]; T14 = R["t14"]; tiers = R["t16_tiers"]; nneg = R["t16_n_neg"]
reason_n = neg.negativereason.value_counts()
top_reason_pct = {k: round(v / nneg * 100, 1) for k, v in reason_n.items()}
worst_air = max(T14, key=lambda a: T14[a]["neg_share"]); best_air = min(T14, key=lambda a: T14[a]["neg_share"])
steps = {s["step"][:2].strip(): s for s in R["t4_steps"]}
S = R["t4_steps"]
sec = []
def add(h): sec.append(h)

# ---------------- header / data note
add(f"""
<header><p class="kick">Data Analysis and Visualization - Lab 11</p>
<h1>What are airline customers telling us on Twitter?</h1>
<p class="sub">Text visualization of {N:,} US airline tweets, {R['date_range'][0][:10]} to {R['date_range'][1][:10]} &middot; Roll No 23I-2530 &middot; Section A</p></header>
<nav>Contents: <a href="#brief">Brief for the Director</a> &middot; <a href="#A">A Cleaning</a> &middot; <a href="#B">B Words &amp; phrases</a> &middot; <a href="#C">C Sentiment tool</a> &middot; <a href="#D">D Airlines &amp; time</a> &middot; <a href="#E">E Critical thinking</a> &middot; <a href="#F">F Extra insights</a></nav>
<section class="note"><h2>Read this first: two data problems found while working</h2>
<p><b>1. The rows labelled "Delta" are really JetBlue.</b> {R['jetblue_fix']['mention_jetblue']:,} of the {R['jetblue_fix']['delta_rows']:,} "Delta" tweets are addressed to @JetBlue and only {R['jetblue_fix']['mention_delta']} mention @delta. For the other five airlines, 100% of tweets contain that airline's own handle. I therefore relabelled the group <b>JetBlue</b> everywhere. Its praise words (Fly-Fi, Mint, "fleet on fleek") confirm it (Part F).</p>
<p><b>2. American's data starts on 22 Feb.</b> American has only {sum(v.get('American', 0) for k, v in R['t15_vol_by_airline'].items() if k < '2015-02-22')} tweet before 22 Feb and about 1,000 per day after, so any time comparison that includes American is distorted (Task 15). Every other number in this report is computed by the script from the tweet file.</p></section>
""")

# ---------------- brief placeholder (filled below, appears near top)
# ---------------- PART A
a = R["t1_prevalence"]
add('<h2 id="A">Part A - Cleaning tweet text</h2>')
add("<h3>Task 1 - What breaks a standard tokenizer</h3>")
add(img("t01_features", "Share of tweets containing each feature that breaks a standard tokenizer"))
rows = [[e["kind"], q(e["text"]), "<code>" + E(" | ".join(e["naive"])) + "</code>"] for e in R["t1_examples"]]
add(tbl(["Feature", "Tweet", "What the naive tokenizer (\\w+) gives"], rows))
add("<p>Every tweet has a handle ({:,}), {:,} have hashtags, {:,} links, {:,} contractions, {:,} non-ASCII characters/emoji and {:,} stretched words. The naive tokenizer turns links into junk fragments (<code>http | t | co | ahlxhh...</code>), splits <i>can't</i> into <code>can | t</code> (the negation is lost) and keeps stretched forms such as <code>heyyyy</code> as separate vocabulary items.</p>".format(a["handles (@user)"], a["hashtags (#tag)"], a["links (http...)"], a["contractions (n't)"], a["non-ASCII / emoji"], a["stretched (sooo)"]))
add(tbl(["Feature", "Treatment", "Justification"], R["t1_decisions"]))
add(f"<p>Stretch collapsing is decided by the vocabulary: a stretched word becomes whichever shorter form (1 or 2 letters) is more common among normal tweets. Examples found: " + ", ".join(f"<code>{a_}</code>&rarr;<code>{b_}</code>" for (a_, b_), _ in R["t1_stretch"][:6]) + f". Only {R['t1_stretch_n']} such tokens exist, so the choice has little effect on results.</p>")

add("<h3>Task 2 - Removing 'not', 'no' and 'nor'</h3>")
add(img("t02_negation", "VADER agreement with the human label, with and without negators in the text"))
add(f"<p>The standard scikit-learn stop list contains {len(R['t2_std_contains_neg'])} negators ({', '.join(R['t2_std_contains_neg'])}). {R['t2_pct_with_negator']}% of tweets ({R['t2_tweets_with_negator']:,}) contain one; <i>not</i> alone appears {dict(R['t2_negator_counts'])['not']:,} times. Removing them changes meaning: <q>website still shows On Time not In Flight</q> becomes the neutral-sounding <q>website shows time flight</q>. Running VADER over the cleaned token streams, <b>{R['t2_sign_flips']:,} tweets change sentiment sign</b>, and agreement with human labels on negator-containing tweets falls from {R['t2_acc_keep_negsub']}% to {R['t2_acc_std_negsub']}%. (Absolute values are low because VADER here reads stripped token lists, not original text; the comparison between the two lists is what matters.)</p>")
ex = R["t2_examples"][1:3]
add(tbl(["Original tweet", "After standard list", "After final list", "VADER std / final", "Human"], [[q(e["text"]), e["std_tokens"], e["keep_tokens"], f"{e['s_std']:+.2f} / {e['s_keep']:+.2f}", e["label"]] for e in ex]))
add(box("decision", f"Final stop list = standard list <b>minus</b> {len(R['t2_final_removed_from_std'])} words that carry meaning (all negators, plus intensifiers/direction words such as <i>very, too, again, still, always, only, down, up, out, off, over, back, after, before</i>), <b>plus</b> tweet noise (<i>amp, rt, via, http, co, u, im, ur</i>). Size: {R['t2_final_stop_size']} words."))

add("<h3>Task 3 - Stemming vs lemmatization</h3>")
add(img("t03_vocab", "Distinct tokens: cleaned, Porter-stemmed, lemmatized"))
v = R["t3_vocab"]
add(f"<p>From {v['after_stop_removal']:,} distinct tokens, Porter stemming leaves {v['stemmed']:,} ({(1 - v['stemmed'] / v['after_stop_removal']) * 100:.0f}% fewer) and lemmatization {v['lemmatized_plain']:,} ({(1 - v['lemmatized_plain'] / v['after_stop_removal']) * 100:.0f}% fewer). They disagree on {R['t3_disagree_n']:,} vocabulary words. Most frequent disagreements:</p>")
add(tbl(["Word", "Uses", "Porter stem", "Lemma"], [[w, c, s_, l_] for w, c, s_, l_ in R["t3_disagree_top"][:12]]))
add("<ul><li><b>Stems that are not words:</b> " + ", ".join(f"{w}&rarr;<code>{s_}</code>" for w, s_, c in R["t3_nonword_stems"][:8]) + ". A Director cannot read a chart with <i>servic</i> or <i>airlin</i> on an axis.</li>"
    "<li><b>Stems that merge different words:</b> <code>custom</code> = customer + customers + <i>customs</i>; <code>tri</code> = try, trying, tried.</li>"
    "<li><b>Lemmatizer faults:</b> <i>cancelled</i>&rarr;<code>cancell</code> (broken, and it is the #1 operational word), <i>united</i>&rarr;<code>unite</code> (an airline), <i>worst</i>&rarr;<code>bad</code> (loses the intensity), <i>did/does</i>&rarr;<code>do</code>.</li></ul>")
add(box("decision", "Use <b>lemmatization</b>, with four small fixes (cancelled/canceled/cancelling/cancellation &rarr; <i>cancel</i>; keep <i>united</i>). Stemming shrinks the vocabulary a little more but produces unreadable labels and merges <i>customer</i> with <i>customs</i>; readable words matter more here because the output goes to a non-technical Director."))

add("<h3>Task 4 - What each cleaning step costs</h3>")
add(img("t04_cost", "Vocabulary, mean tweet length and empty tweets after each cumulative step"))
add(tbl(["Step", "Distinct tokens", "Mean tokens / tweet", "Empty tweets"], [[s_["step"], f"{s_['vocab']:,}", s_["mean_len"], s_["empty"]] for s_ in S]))
add(f"<p>The largest vocabulary cut is step 4 (punctuation/digits/emoji: {S[3]['vocab']:,}&rarr;{S[4]['vocab']:,}), which mostly merges variants such as <i>delayed.</i> / <i>delayed!</i>. <b>Stop-word removal costs the most meaning</b>: it halves tweet length ({S[5]['mean_len']}&rarr;{S[6]['mean_len']} tokens) and empties {S[6]['empty']} tweets (e.g. <q>@VirginAmerica What @dhepburn said.</q>). With the standard list instead, it empties {S[7]['empty']} and deletes every negator. Stripping digits (step 4) also drops numbers such as <i>3 hours</i>, which matters for delays (Part F).</p>")
add(box("decision", "No step went too far <i>with the final stop list</i> (0.3% of tweets empty, negators kept). The standard stop list went too far. For sentiment scoring (Part C) I score the original text, not the cleaned tokens, so cleaning cannot damage that result."))

# ---------------- PART B
add('<h2 id="B">Part B - Words and phrases</h2>')
add("<h3>Task 5 - Airline names and filler dominate raw counts</h3>")
add(img("t05_dominance", "Top 15 words: raw vs after removing handles, airline names and filler"))
add(f"<p>In the raw data the top tokens are function words (<i>to, the, i, a</i>) and handles (<code>@united</code> {dict(R['t5_raw_top'])['@united']:,}, <code>@usairways</code> {dict(R['t5_raw_top'])['@usairways']:,}, <code>@americanair</code> {dict(R['t5_raw_top'])['@americanair']:,}). After basic cleaning, <i>flight</i> still leads ({dict(R['t5_clean_top'])['flight']:,}). The fix removes handles, airline names, generic verbs and the filler list; content words (<i>hour, cancel, delay, service, bag, wait, hold</i>) then appear.</p>")
add(box("finding", f"<b>How the data was collected:</b> {R['t5_starts_with_handle']}% of tweets <i>start</i> with an @handle and 100% contain the labelled airline's own handle. The tweets were gathered by searching for mentions of six airline accounts. So this is people <i>talking to</i> an airline, a self-selected group more likely to be complaining or seeking help ({R['t17']['neg_share']}% negative), not a general sample of travellers."))

add("<h3>Task 6 - Words that truly separate positive from negative</h3>")
add(f"<p>Of each class's 20 most frequent words, <b>{len(R['t6_overlap_pos_neg'])} are shared</b> by positive and negative tweets ({', '.join(R['t6_overlap_pos_neg'])}). Raw frequency ranks words that are common <i>everywhere</i>, so it cannot tell the classes apart.</p>")
add(img("t06_tfidf", "Top TF-IDF words per class (each class treated as one document)"))
add(img("t06_butterfly", "Butterfly chart: log-odds ratio of negative vs positive usage (words used 25+ times)"))
add("<p><b>Negative:</b> " + ", ".join(f"<i>{w}</i> ({a_}:{b_})" for w, z, a_, b_ in R["t6_logodds_neg"][:8]) + ". <b>Positive:</b> " + ", ".join(f"<i>{w}</i> ({b_}:{a_})" for w, z, a_, b_ in R["t6_logodds_pos"][:8]) + ". (Counts are shown as used-in-class : used-in-other-class.) With only three 'documents', TF-IDF's IDF is coarse and still ranks <i>not</i> and <i>hour</i> high; the log-odds butterfly separates the groups more cleanly, so I trust it more.</p>")

add("<h3>Task 7 - Phrases (bigrams and trigrams)</h3>")
add(img("t07_ngrams", "Most frequent bigrams and trigrams in negative tweets"))
chk = {d["bigram"]: d for d in R["t7_flip_check"]}
oc = {d["bigram"]: d["neg"] for d in R["t7_op_check"]}
fl = {r[0]: r for r in R["t7_flip_cands"]}
add(tbl(["Phrase", "Count in negative tweets", "Operational problem it points to"], [
 ["hold over hour / hold hour", f"{oc.get('hold hour', 0) + oc.get('hour hold', 0)} (bigram), 45 (trigram 'hold over hour')", "Phone queue / hold times - a single word like <i>hold</i> or <i>hour</i> would not say it"],
 ["miss connection", oc.get("miss connection", 0), "Late inbound flights breaking connections - a transfer-protection problem"],
 ["booking problem / flight booking problem", "97 / 57", "Booking system or website failures (refunds, changes, duplicate charges)"],
 ["cancel flight", "505", "Cancellations; paired with <i>no</i>/<i>not</i> in trigrams (<i>cancel flight no</i>, 24) = no rebooking offered"]]))
fcand = [fl.get("no worry"), fl.get("no problem")]
add(f"<p><b>Phrase that flips sentiment:</b> <i>no worry</i> (<i>no worries</i>) appears {fl['no worry'][1]} times, {fl['no worry'][2]} of them in <b>positive</b> tweets, although <i>no</i> and <i>worry</i> are both negative in the VADER lexicon (scores {fl['no worry'][3][0]} and {fl['no worry'][3][1]}). Likewise <i>no problem</i> ({chk['no problem']['total']} uses, {chk['no problem']['in_positive']} positive). A negator plus a negative word makes a positive.</p>")

add("<h3>Task 8 - Word cloud or bar chart?</h3>")
add(img("t08_cloud_vs_bar", "The same negative words as a word cloud and as a bar chart"))
tt = R["t8_top"]
add(f"<p>The cloud gives a fast mood ('cancel, hour, delay, service...'), but size encodes <i>area</i>, long words look bigger than short ones, position is arbitrary, and nobody can tell that <i>{tt[0][0]}</i> ({tt[0][1]:,}) is about {tt[0][1] / tt[4][1]:.1f}x <i>{tt[4][0]}</i> ({tt[4][1]:,}). The bar chart shows exact counts and a ranking on a common baseline.</p>")
add(box("decision", "Show the Director the <b>bar chart</b>. The Director must decide where to act first, which needs a ranking and sizes that can be compared. The word cloud is fine as a decorative cover image only."))

# ---------------- PART C
add('<h2 id="C">Part C - Sentiment tool vs human labels</h2>')
add("<h3>Task 9 - How well do they agree?</h3>")
add(img("t09_confusion", "Confusion matrix: VADER (compound &ge; 0.05 positive, &le; -0.05 negative) vs human labels"))
add(tbl(["Human class", "Precision", "Recall", "F1", "Tweets"], [[c, t9[c]["precision"], t9[c]["recall"], t9[c]["f1-score"], int(t9[c]["support"])] for c in cls]))
add(f"<p><b>Overall agreement is {R['t9_acc']}%</b> (TextBlob: {R['t9_acc_tb']}%; macro-F1 {R['t9_macro_f1']}%). That is <b>lower than the {R['t9_baseline_always_neg']}% obtained by labelling every tweet 'negative'</b>. Neutral is the hardest class (F1 {t9['neutral']['f1-score']}). The single number hides an asymmetry: when VADER says <i>negative</i> it is right {t9['negative']['precision'] * 100:.0f}% of the time, but it finds only <b>{t9['negative']['recall'] * 100:.0f}% of the real complaints</b>; {R['t9_cm'][0][2]:,} human-negative tweets are called positive. Its positive class is the opposite: recall {t9['positive']['recall'] * 100:.0f}%, precision only {t9['positive']['precision'] * 100:.0f}%.</p>")
add(img("t09_box", "Distribution of VADER compound scores for each human class"))

add("<h3>Task 10 - Where and why they disagree</h3>")
add(img("t10_causes", "Disagreements grouped by cause (rule-based tagging, first matching rule wins)"))
cz = R["t10_causes"]
add(tbl(["Cause", "Tweets", "Share of disagreements", "Example"], [[k, f"{v:,}", pct(v, R["t10_n_disagree"]), q(R["t10_examples_by_cause"][k][0]["text"]) + f' <small>human={R["t10_examples_by_cause"][k][0]["label"]}, VADER={R["t10_examples_by_cause"][k][0]["vader"]:+.2f}</small>'] for k, v in cz.items()]))
add(f"<p>{R['t10_n_disagree']:,} of {N:,} tweets ({R['t10_pct_disagree']}%) disagree. The <b>largest cause is airline vocabulary</b> ({cz['Airline words not negative in lexicon']:,}): human-negative tweets containing <i>delayed, cancelled, lost, hold, wait, hours, luggage</i> that VADER scores as non-negative. Sarcasm is surprisingly small by my rules ({cz['Sarcasm / irony']}), but my sarcasm detector only catches obvious phrases, so treat it as a lower bound; the 'Other' bucket also holds emoji-only and spam cases. Tagging is rule-based and approximate.</p>")
add(img("t10_fix", "Agreement before and after adding airline words to the lexicon"))
add(box("decision", f"<b>Fix:</b> add airline words to the lexicon with negative scores (e.g. delayed -2.2, cancelled -2.4, lost -2.0, stuck -2.0, hold -1.2; list in the script). Agreement rises {R['t9_acc']}% &rarr; {R['t10_acc_fixed']}% and negative recall {t9['negative']['recall'] * 100:.0f}% &rarr; {R['t10_recall_fixed']['negative'] * 100:.0f}% (missed complaints {R['t10_neg_missed'][0]:,} &rarr; {R['t10_neg_missed'][1]:,}). It is still below the always-negative baseline, so a general lexicon, even patched, is not enough; the next step would be a classifier trained on these {N:,} labelled tweets (not tested here)."))

add("<h3>Task 11 - Three tweets where counting words misleads</h3>")
add(tbl(["Type", "Tweet I wrote", "Positive words / negative words found", "VADER", "Why it fails"], [
 [t["type"], q(t["text"]), f"+: {', '.join(t['pos_words'])}<br>-: {', '.join(t['neg_words'])}", f"{t['compound']:+.2f} ({t['label']})", why] for t, why in zip(R["t11"], [
  "A clear refusal ('can't say I was happy', 'wouldn't fly with you again') scores positive. VADER flips a polar word only if it is within three words after the negator; <i>happy</i> is further away, <i>wouldn't fly</i> has no polar word, and <i>free</i> adds a positive (it even counts the airline name <i>united</i> as a positive word).",
  "Sarcasm: 'thanks', 'great job', 'love' are positive words, 'losing' only one negative. Counting words gives +0.87 for an angry customer. Nothing in the words reveals the irony.",
  "Mixed feelings plus domain words: <i>cancelled, stuck, no</i> are negative but one positive word (<i>lovely</i>) pulls the score to +0.56. The customer's real problem (stranded, no rebooking) is the main message; the praise is secondary. Even with my airline lexicon it stays positive (+0.34).",
  "Bonus - repetition: 'good' counted 4 times plus 'luck' and 'happy' give +0.95; the bad part (app crashed, nobody helped) has no lexicon words at all."])]))
add("<p>Each case is a sentence-level meaning that a bag of words cannot represent: negation scope, irony, and which part of the message the writer cares about.</p>")

add("<h3>Task 12 - Human labels also disagree</h3>")
add(img("t12_confidence", "Left: VADER agreement by label confidence. Right: class mix, all labels vs confidence &ge; 0.8"))
hi, lo_ = R["t12_hi"], R["t12_lo"]
add(f"<p>The confidence column is almost two-valued: {R['t12_conf_dist']['==1.0']:,} tweets sit at exactly 1.0 and {R['t12_conf_dist']['<0.7']:,} ({R['t12_conf_dist']['<0.7'] / N * 100:.0f}%) are below 0.7, i.e. labelling humans did not agree. Keeping only confidence &ge; 0.8 ({hi['n']:,} tweets):</p>")
add(tbl(["", "All labels", "Confidence &ge; 0.8", "Confidence < 0.8"], [
 ["VADER agreement", f"{R['t9_acc']}%", f"{hi['acc']}%", f"{lo_['acc']}%"],
 ["Negative share", f"{R['t12_all_shares']['negative']}%", f"{hi['shares']['negative']}%", f"{lo_['shares']['negative']}%"],
 ["Neutral share", f"{R['t12_all_shares']['neutral']}%", f"{hi['shares']['neutral']}%", f"{lo_['shares']['neutral']}%"],
 ["Airline ranking by negative share", " > ".join(R["t12_rank_all"][:3]) + " ...", "same order", "-"],
 ["Top-30 negative words shared", "-", f"{R['t12_top_words_overlap']} of 30", "-"]]).replace("&amp;ge;", "&ge;"))
add(box("finding", "Conclusions that I take from this: the <b>airline ranking and top words do not change</b> (robust). Tool agreement gets better on clear-cut labels ({:.0f}% vs {:.0f}%), meaning part of the 'error' in Task 9 comes from ambiguous tweets where even humans split. Low-confidence labels are mostly neutral/positive-looking tweets, so using all labels slightly <i>under</i>states how negative the clear-cut tweets are. The 'ground truth' is a noisy opinion, not a fact; even on clear-cut labels the tool only reaches about 60%.".format(hi["acc"], lo_["acc"])))

# ---------------- PART D
add('<h2 id="D">Part D - Airlines and time</h2>')
add("<h3>Task 13 - Service problem vs operations problem</h3>")
add(img("t13_mix", "Left: complaint reasons per airline. Right: service vs operations share of known-reason complaints"))
gp, rate = R["t13_group_pct"], R["t13_rate_per_100"]
add(tbl(["Airline", "Service share", "Operations share", "Service complaints per 100 tweets", "Operations complaints per 100 tweets"], [[a_, f"{gp[a_]['Service']}%", f"{gp[a_]['Operations']}%", rate[a_]["service"], rate[a_]["ops"]] for a_ in sorted(gp, key=lambda x: -gp[x]["Service"])]))
add(f"<p>Service = customer-service issues + flight-attendant complaints; operations = late, cancelled, lost/damaged luggage, long lines; 'Can't Tell' excluded. The mix differs significantly by airline (chi-square on all reasons = {R['t13_chi2']['chi2']}, p &lt; 0.001, Cramer's V = {R['t13_chi2']['cramers_v']}: real but modest). <b>The Director's belief is supported:</b> American ({gp['American']['Service']}%) and US Airways ({gp['US Airways']['Service']}%) skew to service; JetBlue ({gp['JetBlue']['Operations']}% operations, with Late Flight 28% of its complaints) and United ({gp['United']['Operations']}%) skew to operations. Caveat: per 100 tweets, <b>US Airways is high on both</b> ({rate['US Airways']['service']} service, {rate['US Airways']['ops']} ops), so it has a general problem; the 'skew' tells you which one to fix first, not that the other is fine.</p>")

add("<h3>Task 14 - Raw count vs share</h3>")
add(img("t14_count_vs_share", "Negative tweets: raw count and share of the airline's tweets with 95% interval"))
add(f"<p><b>United</b> has the most negative tweets ({T14['United']['neg']:,}) simply because it has the most tweets ({T14['United']['tweets']:,}); its negative share ({T14['United']['neg_share']}%) is below US Airways ({T14['US Airways']['neg_share']}%) and American ({T14['American']['neg_share']}%). Virgin America has the fewest negative tweets ({T14['Virgin America']['neg']}) and also the lowest share ({T14['Virgin America']['neg_share']}%), but with only {T14['Virgin America']['tweets']} tweets its interval is wider ({T14['Virgin America']['lo']}-{T14['Virgin America']['hi']}%).</p>")
add(box("decision", "<b>Report share</b> (with its interval) for comparing airlines, and report raw counts only for workload ('United needs the biggest team'). Share is not driven by how many people follow or tweet to the airline. Note that American's counts cover three days only (Task 15), so its raw count is not comparable at all."))

add("<h3>Task 15 - Spikes and patterns over time</h3>")
add(img("t15_time", "Volume by airline, daily negative share with and without American, and share by airline-day"))
d2 = dict((r[0], r[2]) for r in R["t15_excl_american"])
add(f"<p><b>Two things happen on 22 Feb.</b> (1) Volume doubles (1,557 to 3,079 tweets), but about 1,000 of the tweets per day are <b>American, which appears in the data only from 22 Feb</b>. Without American the rise is {R['t15_core_volume']['2015-02-21']:,} to {R['t15_core_volume']['2015-02-22']:,} (+34%). Most of the jump is collection, not a surge. (2) Negative share, even excluding American, rises from about 55% (17-20 Feb) to {d2['2015-02-21']}% on 21 Feb and {d2['2015-02-22']}% on 22 Feb, then returns to {d2['2015-02-23']}% on 23 Feb. The rise is led by JetBlue (about 40% &rarr; 62% on 22 Feb), US Airways (87%), Southwest (69% on 21 Feb) and Virgin America. The all-airline 23 Feb value of 63% is higher only because American's 72% is included.</p>")
add(f"<p><b>Can the data say why?</b> Partly. On 21-22 Feb cancellation complaints rise (from about 5% of negative tweets to 12%) and late-flight complaints stay near 16-20%, so more disruption. But weather words (<i>storm, snow, ice, winter</i>) appear in only 1.7-4.9% of tweets on any day, with no jump, so the text does not name a cause. The data cannot separate a real operational event from a change in who was being sampled; an external record (flight cancellation logs, weather reports) would be needed. Also only about 8 days: no weekly pattern can be judged.</p>")

add("<h3>Task 16 - Which negative tweets to answer first</h3>")
add(img("t16_tiers", "Negative tweets by priority tier"))
add(tbl(["Signal", "Points", "Why"], [
 ["Time-critical reason (cancelled, late, booking problem, lost luggage)", "+3", "The customer can still be helped now (rebook, locate bag); a late reply = lost value"],
 ["Urgency words (stuck, stranded, missed, hours, rebook, please, help, still...)", "+2", "The customer says in their own words that they are waiting"],
 ["Already shared (at least 1 retweet)", "+2", f"Public reach: {R['t16_reach']['neg_with_rt']} negative tweets hold {R['t16_reach']['all_rt_share_neg']}% of all retweets"],
 ["Repeat complainer (2+ negative tweets in the period)", "+1", f"{R['t16_repeat_users']:,} users; earlier failure to resolve"],
 ["Gate: label confidence &ge; 0.8", "-", "Low-confidence tweets go to a human reviewer first (we are unsure it is a complaint)"]]).replace("&amp;ge;", "&ge;"))
add(f"<p><b>P1 (score &ge; 6): {tiers['P1 - answer within the hour']:,} tweets ({pct(tiers['P1 - answer within the hour'], nneg)}) within the hour; P2 (3-5): {tiers['P2 - same day']:,} ({pct(tiers['P2 - same day'], nneg)}) same day; P3 (&lt; 3): {tiers['P3 - batch / auto-reply']:,} ({pct(tiers['P3 - batch / auto-reply'], nneg)}) batch/auto-reply; review: {tiers['Review (low label confidence)']:,} ({pct(tiers['Review (low label confidence)'], nneg)}).</b> Over about 8 days that is roughly {tiers['P1 - answer within the hour'] / 8:.0f} P1 tweets a day, a workload a small team can handle.</p>")
add(f"<p><b>Defence and limits:</b> the rule uses only what the data contains and what a live system could see (reason words, retweets, repeat authors). The weights are my judgement, not fitted to an outcome, since the data has no 'was resolved' field. Known gaps: keyword urgency misses sarcasm (<i>'Thank U for the 1hr delay...'</i> falls into P3), and in production the human reason label must be replaced by a keyword/classifier guess.</p>")

# ---------------- PART E
t17 = R["t17"]
add('<h2 id="E">Part E - Critical thinking</h2>')
add("<h3>Task 17 - Ways this dataset could mislead</h3>")
add(f"""<ol>
<li><b>Self-selection.</b> {R['t5_starts_with_handle']}% of tweets start with an airline handle: these are customers who chose to address the airline, {t17['neg_share']}% of them negatively. Satisfied silent passengers and people who complain elsewhere are missing; the negative share is not the satisfaction level of travellers.</li>
<li><b>Skewed authors and uneven collection.</b> {t17['unique_users']:,} users wrote {N:,} tweets; brand/news accounts appear (JetBlueNews alone has {t17['top_user_tweets']['JetBlueNews']} tweets), the top 1% of users wrote {t17['tweets_by_top1pct']}% of the data, and American Airlines only enters from 22 Feb. Only {t17['has_location']}% of tweets give a location and {t17['has_coord']}% coordinates, so geography is mostly unknown; time zones lean Eastern ({t17['top_tz']['Eastern Time (US & Canada)']}%).</li>
<li><b>Labelling issues.</b> The 'Delta' label is really JetBlue (see top), {t17['cant_tell_of_neg']}% of negative tweets have reason 'Can't Tell', {R['t12_conf_dist']['<0.7'] / N * 100:.0f}% of tweets have label confidence below 0.7, and only {t17['gold_rows']} rows are 'gold' (checked) labels.</li>
<li><b>Short window.</b> 8 days around one event (see Task 15) tells us nothing about normal weeks.</li></ol>""")
add(box("finding", "<b>I trust least:</b> (a) <b>the daily trend and the explanation of the 22 Feb spike</b>, which is confounded by American entering the sample and by one disruption period, and (b) <b>any comparison involving American's counts or Virgin America's shares</b> (3 days of data; 504 tweets). I trust most: the ranking of complaint reasons and the airline share ranking, which hold with or without low-confidence labels."))

add("<h3>Task 18 - What would change with data from today</h3>")
add(f"""<p>These are predictions based on what I know about the industry and the platform, not tested on data:</p><ul>
<li><b>Different airlines.</b> US Airways merged into American (2015) and Virgin America was acquired by Alaska (2016, brand retired later), so these labels and their comparison would disappear; new carriers (e.g. Spirit, Frontier, Alaska) would appear.</li>
<li><b>Platform changes.</b> 140-character tweets became 280; length is a strong negativity signal here (Part F), so that signal would change. Emoji appear in {R['t18_emoji_tweets_pct']}% of these tweets and would be far more common and a bigger sentiment signal. Twitter is now X, with a different user base and API.</li>
<li><b>Different complaints.</b> <i>Customer service</i> and <i>late/cancelled</i> are structural and likely to stay on top. I would expect more refunds/credits, app and Wi-Fi issues (already {R['t18_mention_other_brands']['refund']} refund, {R['t18_mention_other_brands']['app']} app, {R['t18_mention_other_brands']['wifi']} Wi-Fi mentions) and staffing/pandemic-related disruptions. Phone hold complaints may shrink as service moves to chat and DMs.</li>
<li><b>Tools.</b> Modern language models handle sarcasm, emoji and negation much better than a 2014 lexicon, so the Task 9 result (55% agreement) would improve; the airline-word problem would shrink.</li></ul>""")

add("<h3>Task 19 - Replace the manual team with the tool?</h3>")
add(box("decision", f"<b>No - not as it stands; use it to sort, not to decide.</b>"))
add(f"""<ul><li><b>Against replacing:</b> overall agreement {R['t9_acc']}% is below the {R['t9_baseline_always_neg']}% of a rule that calls everything negative; it misses {(1 - t9['negative']['recall']) * 100:.0f}% of real complaints ({R['t9_cm'][0][2]:,} complaints read as positive), and its 'positive' calls are right only {t9['positive']['precision'] * 100:.0f}% of the time. Sarcasm, double negatives and mixed messages (Task 11) are the exact tweets a customer-care team most needs to catch.</li>
<li><b>For using it:</b> when it says 'negative' it is right {t9['negative']['precision'] * 100:.0f}% of the time, it finds {t9['positive']['recall'] * 100:.0f}% of positives, it reads {N:,} tweets in seconds, and with airline words added it improves to {R['t10_acc_fixed']}%. The human labels themselves are noisy ({R['t12_conf_dist']['<0.7'] / N * 100:.0f}% low confidence), so humans are not perfect either.</li>
<li><b>Recommendation:</b> let software count and route (volume dashboards, P1/P2/P3 triage from Task 16, a daily top-word report) and keep a small human team for what the tool cannot judge: low-confidence/neutral tweets, anything the tool calls positive but contains a delay/cancel/loss word, and a weekly 200-tweet audit that tracks tool accuracy. Re-evaluate once a classifier trained on these labelled tweets exists.</li></ul>""")

# ---------------- PART F
add('<h2 id="F">Part F - Additional insights</h2>')
f1, f2, f3 = R["f1"], R["f2"], R["f3"]
def ins(title, obs, ev, why, act, conf, fig=None):
    return f'<div class="ins"><h3>{title}</h3>' + tbl(["Element", "What I found"], [["Observation", obs], ["Evidence", ev], ["Why it matters", why], ["Recommended action", act], ["Confidence and limits", conf]], "kv") + "</div>"
add(img("tF_insights", "Typing cues by label (left), duration mentions by complaint reason (middle), retweet rate by label (right)"))
add(ins("Insight 1 - The phone queue is the customer-service pain",
 f"Customer-service complaints are about waiting on the phone, and waits are measured in hours.",
 f"{f1['neg_with_duration_pct']}% of negative tweets state a duration (hours/minutes) vs {f1['pos_with_duration_pct']}% of positive tweets; for Late Flight {f1['by_reason']['Late Flight']}% and for Customer Service {f1['by_reason']['Customer Service Issue']}%. {f1['cs_phone_pct']}% of customer-service complaints mention phone/call/hold, and <i>hold</i> ({dict(f1['cs_words'])['hold']}) and <i>hour</i> ({dict(f1['cs_words'])['hour']}) are among their top words (trigram: 'hold over hour', 45).",
 "Customer service is the largest complaint reason (31.7% of all negative tweets) and highest at American (39% of its complaints) and US Airways (36%). A specific, fixable cause (queue length) is behind a vague label.",
 "Track and publish phone wait time; offer call-back and chat/DM as alternatives; route tweets that mention a wait to P1 (Task 16 already does). Aim first at American and US Airways.",
 "Medium-high. Based on counts of words in tweets, not real call logs; durations are what customers say, not measured; tweets that mention a number lose it in my cleaning, so I counted them from the raw text."))
add(ins("Insight 2 - Complaints travel further than praise",
 f"Negative tweets are twice as likely to be retweeted, and a few get large audiences.",
 f"{f2['rate_by_sent']['negative']:.1f}% of negative tweets are retweeted vs {f2['rate_by_sent']['positive']:.1f}% positive and {f2['rate_by_sent']['neutral']:.1f}% neutral; negative tweets carry {R['t16_reach']['all_rt_share_neg']}% of all {f2['rt_total']:,} retweets. The top tweets (e.g. 44 retweets, a 5-hour delay at US Airways) are all complaints.",
 "A complaint left unanswered is seen by more than one person. {} of the retweets go to United and US Airways combined.".format(f"{(f2['rt_by_airline']['United'] + f2['rt_by_airline']['US Airways']) / f2['rt_total'] * 100:.0f}%"),
 "Treat a retweeted complaint as a public incident: answer in public, fast, and include retweet count as a trigger (done in the Task 16 rule).",
 "High for the pattern, low for the amounts: only {} tweets ({}%) have any retweet and the maximum is {}, so the totals rest on a handful of tweets.".format(f2["tweets_with_rt"], f2["pct"], R["t16_reach"]["max_rt"])))
add(img("tF_length", "Share of negative tweets by tweet length"))
add(ins("Insight 3 - Length and punctuation reveal intent without any lexicon",
 "Long tweets are complaints, exclamation marks are praise, and question marks are neutral requests.",
 f"Negative share rises from {f3['neg_by_len']['<=70']}% (up to 70 characters) to {f3['neg_by_len']['121-140']}% (121-140). Average length: negative {f3['len_by_sent']['negative']:.0f} characters vs {f3['len_by_sent']['positive']:.0f} positive. '!' appears in {f3['excl_by_sent']['positive']}% of positive tweets vs {f3['excl_by_sent']['negative']}% of negative; '?' in {f3['qm_by_sent']['neutral']}% of neutral vs {f3['qm_by_sent']['positive']}% of positive.",
 "These cues cost nothing to compute and do not suffer from the lexicon problems in Task 10. People who have a story to tell (what happened, how long, who they spoke to) use all the characters.",
 "Add length, '!' and '?' as features to any triage model; use '?' to send simple questions to a self-service or FAQ reply.",
 "Medium. Correlation, not cause; a different character limit (280 today) will move the length numbers; ALL-CAPS was not a useful cue ({}% negative vs {}% positive).".format(f3["caps_by_sent"]["negative"], f3["caps_by_sent"]["positive"])))
pr = R["f4_praise"]
add(ins("Insight 4 - What each airline is praised for differs, and it is perks and products, not crew",
 "Praise is driven by programmes and products, such as Southwest's Destination Dragons and Companion Pass, JetBlue's Fly-Fi, Mint and 'fleet on fleek'.",
 "Most over-represented positive words (compared with other airlines): Southwest - " + ", ".join(w for w, c, l in pr["Southwest"][:4]) + "; JetBlue - " + ", ".join(w for w, c, l in pr["JetBlue"][:4]) + f"; United - " + ", ".join(w for w, c, l in pr["United"][:3]) + f". Staff words (crew, agent, pilot...) appear in only {R['f4_staff_mention']['pos']}% of positive tweets. {R['f4_thanks_pos']}% of positive tweets contain 'thank'.",
 "Marketing campaigns and loyalty features generate positive tweets that service recovery does not; a share of positive tweets are thanks after a problem was fixed.",
 "Keep and promote the visible perks; collect the 'thank you' tweets as a measure of service-recovery success and share them with the staff involved.",
 "Medium-low. Small counts per airline (8-21 uses per word) and campaign hashtags (Destination Dragons) are one-off; the word list is a pointer, not a ranking."))
add(img("tF_venn", "Venn diagram: negative-tweet vocabulary shared between the worst and a mid-ranked airline"))
vn = R["venn"]
add(f"<p><small>Chart-catalogue item (Venn): {vn['shared_n']} words used 8+ times are shared between US Airways and Southwest negative tweets; the words unique to US Airways are mostly its hub cities (Charlotte, Philadelphia, Phoenix, Boston), and Southwest's are its own (Dallas, Denver, Vegas, BWI). Vocabulary is largely shared, so the problems are the same across airlines; they differ in size and mix (Task 13).</small></p>")

# ---------------- ONE-PAGE BRIEF
airs = sorted(T14, key=lambda a: -T14[a]["neg_share"])
brief = f"""
<div class="brief"><div class="bhead"><div><p class="kick">Customer insights brief &middot; 14,640 airline tweets, 16-24 Feb 2015</p><h1>Complaints are mostly about waiting and cancelled flights - and software alone cannot read them</h1></div></div>
<div class="cols">
<div><h4>1. What customers say</h4>
<p><b>{R['t17']['neg_share']}%</b> of tweets sent to the airlines are complaints. Largest reasons: <b>customer service</b> ({top_reason_pct['Customer Service Issue']}% of complaints), <b>late flights</b> ({top_reason_pct['Late Flight']}%), <b>cancellations</b> ({top_reason_pct['Cancelled Flight']}%), <b>lost luggage</b> ({top_reason_pct['Lost Luggage']}%). In their words: <i>"hold over an hour"</i>, <i>"cancelled flight, no rebooking"</i>, <i>"missed connection"</i>, <i>"hang up"</i>. Praise is short ("great", "love", "thank") and tied to perks and products.</p></div>
<div><h4>2. Can software replace reading?</h4>
<p><b>Not yet.</b> A standard sentiment tool agrees with human labels only <b>{R['t9_acc']}%</b> of the time, less than calling everything negative ({R['t9_baseline_always_neg']}%). It misses about half of real complaints, mostly those using airline words such as <i>delayed</i> and <i>cancelled</i>, plus sarcasm. Adding airline words lifts it to {R['t10_acc_fixed']}%. Use it to <b>sort and count</b>, keep people for judgement.</p></div></div>
<div class="chart">{img("t14_count_vs_share", "")}</div>
<div class="cols">
<div><h4>3. How airlines compare</h4>
<p>Share of tweets that are negative: {', '.join(f'<b>{a_}</b> {T14[a_]["neg_share"]:.0f}%' for a_ in airs)}. <b>American and US Airways</b> lean to service problems ({gp['American']['Service']:.0f}% / {gp['US Airways']['Service']:.0f}% of complaints); <b>United and JetBlue</b> lean to operations (delays, cancellations: {gp['United']['Operations']:.0f}% / {gp['JetBlue']['Operations']:.0f}%). US Airways is high on both.</p>
<p class="small">Note: the file's "Delta" rows are really JetBlue; American appears only from 22 Feb.</p></div>
<div><h4>4. Act first on</h4>
<ol><li><b>Phone queues and customer service</b> at American and US Airways: wait time, call-back, chat.</li>
<li><b>Disruption messaging</b> at United and JetBlue: tell people early about delays/cancellations and rebook automatically.</li>
<li><b>Answer first</b> the {tiers['P1 - answer within the hour']:,} urgent tweets ({pct(tiers['P1 - answer within the hour'], nneg)} of complaints): travel-critical reason, stuck/waiting, or already retweeted.</li>
<li><b>Hybrid team:</b> software sorts, humans review unclear cases and audit weekly.</li></ol></div></div>
<p class="small foot">Limits: tweets sent <i>to</i> airlines over 8 days; complaints are over-represented; the 22 Feb rise ({d2['2015-02-22']}% negative vs about 55%) cannot be explained from this data. Full method and charts in the report.</p></div>
"""
BRIEF = brief
css = """
:root{--bg:#fff;--fg:#23272e;--mut:#5d6470;--line:#e3e5e8;--card:#f6f7f9;--acc:#2b7bba;--neg:#d1522a;--box:#eef5fb}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#15181d;--fg:#e8eaed;--mut:#a2a8b2;--line:#2c3138;--card:#1d2127;--acc:#6aaee6;--neg:#ee8760;--box:#1b2733}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:980px;margin:0 auto;padding:24px 16px 80px}header{padding:28px 0 8px}h1{font-size:28px;line-height:1.2;margin:4px 0}h2{font-size:22px;margin:44px 0 8px;padding-top:14px;border-top:2px solid var(--line)}h3{font-size:17px;margin:30px 0 6px}
.kick{text-transform:uppercase;letter-spacing:.08em;font-size:11px;color:var(--mut);margin:0}.sub{color:var(--mut);margin:4px 0}nav{font-size:13px;color:var(--mut);margin:10px 0 18px}nav a{color:var(--acc)}
figure{margin:12px 0}figure img{max-width:min(100%,860px);height:auto;border:1px solid var(--line);border-radius:8px;background:#fff}figcaption{font-size:12px;color:var(--mut);margin-top:4px}
table{border-collapse:collapse;width:100%;margin:10px 0;font-size:13.5px}th,td{border-bottom:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top}th{background:var(--card);font-weight:600}
table.kv td:first-child{width:170px;font-weight:600;background:var(--card)}
.tw{color:var(--mut);font-style:italic}.box{border-left:4px solid var(--acc);background:var(--box);padding:8px 12px;margin:12px 0;border-radius:0 6px 6px 0}.box.finding{border-color:var(--neg)}
.note{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:4px 16px;margin:12px 0}.note h2{border:0;margin:10px 0 0;font-size:17px}
code{background:var(--card);padding:1px 4px;border-radius:3px;font-size:12.5px;overflow-wrap:anywhere}.ins{margin:8px 0 22px}small{color:var(--mut)}
.brief{border:2px solid var(--fg);border-radius:6px;padding:18px 20px;margin:18px 0}.brief h1{font-size:21px}.brief h4{margin:6px 0 2px;font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:var(--acc)}.brief p,.brief li{font-size:13px;margin:3px 0}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.chart figure{margin:6px 0}.small{font-size:11px!important;color:var(--mut)}.foot{border-top:1px solid var(--line);margin-top:8px!important;padding-top:6px}
@media(max-width:700px){.cols{grid-template-columns:1fr}h1{font-size:22px}}
@media print{.brief{break-inside:avoid}}
"""
page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Lab 11 Airline Tweets</title><style>{css}</style></head><body><main>
{sec[0]}<h2 id="brief">One-page brief for the Director</h2><p><small>Also saved as a separate one-page PDF.</small></p>{BRIEF}{''.join(sec[1:])}
<p><small>Everything above was computed by the script in this file (23I-2530_A_Lab11.py) from Tweets.csv; each figure in the text is read from results.json. Sentiment scoring uses VADER (and TextBlob for comparison).</small></p></main></body></html>"""
open("report.html", "w", encoding="utf-8").write(page)
bp = f"""<!doctype html><html><head><meta charset="utf-8"><title>Brief</title><style>{css}
body{{font-size:13px}}main{{padding:0}}.brief{{border:0;padding:0;margin:0}}.brief h1{{font-size:19px}}@page{{size:A4;margin:12mm}}</style></head><body><main>{BRIEF}</main></body></html>"""
open("brief.html", "w", encoding="utf-8").write(bp)
print("report built")
