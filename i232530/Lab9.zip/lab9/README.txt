Lab 9 - how to run
1. Unzip, open the folder in VS Code (File > Open Folder).
2. Install the "Live Server" extension (Ritwick Dey).
3. Right-click index.html > Open with Live Server. Click each task link.
(Do not double-click the HTML files: d3.csv/d3.json need a server.)
