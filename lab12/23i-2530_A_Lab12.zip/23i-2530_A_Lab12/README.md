# Lab 12 – 23i-2530 (Section A)
- `23i-2530_A_Lab12_Report.docx` – Lab report / prompt log (Tasks 1–8)
- `23i-2530_A_Lab12.ipynb` – Verification notebook (Restart & Run All, zero errors)
- `dataset/shopease_orders.csv` – data; `figs/` – charts used in the report
